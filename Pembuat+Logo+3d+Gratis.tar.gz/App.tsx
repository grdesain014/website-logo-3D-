import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Sparkles, Download, Copy, Shuffle, RotateCcw, Play, Wand2, Crown, Star, Heart, Shield, Box, Circle, Check, ChevronDown, Palette, Type, SlidersHorizontal, Shapes, Zap, BadgeCheck, Layers, MonitorDown, Save, Trash2, FolderOpen, MousePointerClick, PenLine, Rocket, X, Menu, ImageOff, Lightbulb, Sun, Eye, Droplets, Plus, Undo2, Redo2, AlignCenter, AlignLeft, AlignRight, ZoomIn, EyeOff, Copy as CopyIcon, ChevronUp, ChevronDown as ChevronDownIcon, Trash, Move, RotateCw, Heart as HeartIcon, HelpCircle } from 'lucide-react';

type Design = { text:string; font:string; color:string; color2:string; gradient:string; bg:string; transparent:boolean; size:number; depth:number; rotX:number; rotY:number; tilt:number; shape:string; style:string; anim:string; shadowColor:string; glow:number; bgMode:string };
const DEFAULTS: Design = { text:'BRANDKU', font:'Poppins Bold', color:'#ffffff', color2:'#ec4899', gradient:'Ungu-Pink', bg:'#17102f', transparent:false, size:72, depth:18, rotX:12, rotY:-18, tilt:0, shape:'Bintang', style:'Warna Campuran', anim:'Putar', shadowColor:'#3b0764', glow:28, bgMode:'solid' };
const GRADIENTS: Record<string,string> = { 'Ungu-Pink':'linear-gradient(135deg,#a855f7,#ec4899,#f97316)', 'Biru-Cyan':'linear-gradient(135deg,#2563eb,#06b6d4,#22c55e)', 'Emas':'linear-gradient(135deg,#f59e0b,#fde68a,#b45309)', 'Hijau Neon':'linear-gradient(135deg,#22c55e,#a3e635,#06b6d4)', 'Merah Api':'linear-gradient(135deg,#ef4444,#f97316,#facc15)', 'Putih Bersih':'linear-gradient(135deg,#ffffff,#cbd5e1,#ffffff)', 'Custom':'linear-gradient(135deg,#ffffff,#ec4899)' };
const FONTS: Record<string,string> = { 'Poppins Bold':"'Poppins',sans-serif", 'Montserrat ExtraBold':"'Montserrat',sans-serif", 'Bebas':"'Bebas Neue',sans-serif", 'Playfair':"'Playfair Display',serif", 'Monospace':"'JetBrains Mono',monospace" };
const SHAPES = ['Kubus','Bola','Bintang','Hati','Mahkota','Perisai'];
const STYLES = ['Metalik','Neon Glow','Kaca / Glass','Matte','Warna Campuran'];
const ANIMS = ['Putar','Melayang','Memantul','Berkilau'];
const TEMPLATES: {name:string; cat:string; d:Partial<Design>}[] = [
  {name:'Gaming Pro',cat:'Gaming',d:{text:'NOVA',gradient:'Merah Api',style:'Neon Glow',shape:'Perisai',font:'Montserrat ExtraBold'}},
  {name:'Kopi Senja',cat:'Cafe',d:{text:'SENJA',gradient:'Emas',style:'Metalik',shape:'Bola',font:'Playfair'}},
  {name:'Toko Ceria',cat:'Toko Online',d:{text:'BELANJA',gradient:'Ungu-Pink',style:'Warna Campuran',shape:'Hati',font:'Poppins Bold'}},
  {name:'Esports Juara',cat:'Esports',d:{text:'APEX',gradient:'Biru-Cyan',style:'Neon Glow',shape:'Mahkota',font:'Bebas'}},
  {name:'Glow Beauty',cat:'Beauty',d:{text:'CANTIK',gradient:'Ungu-Pink',style:'Kaca / Glass',shape:'Bintang',font:'Playfair'}},
  {name:'Tekno Masa Depan',cat:'Teknologi',d:{text:'TEKNO',gradient:'Biru-Cyan',style:'Metalik',shape:'Kubus',font:'Monospace'}},
  {name:'Nada Musik',cat:'Musik',d:{text:'MELODI',gradient:'Merah Api',style:'Neon Glow',shape:'Bola',font:'Bebas'}},
  {name:'Cerdas Belajar',cat:'Pendidikan',d:{text:'CERDAS',gradient:'Hijau Neon',style:'Matte',shape:'Perisai',font:'Montserrat ExtraBold'}},
];
const INSPO = [
  {t:'ORBIT',g:'Biru-Cyan',s:'Metalik',sh:'Bola'}, {t:'LUNA',g:'Ungu-Pink',s:'Kaca / Glass',sh:'Bintang'}, {t:'RAJA',g:'Emas',s:'Metalik',sh:'Mahkota'}, {t:'PELITA',g:'Merah Api',s:'Neon Glow',sh:'Hati'}, {t:'ATLAS',g:'Hijau Neon',s:'Matte',sh:'Kubus'}, {t:'VIBE',g:'Ungu-Pink',s:'Warna Campuran',sh:'Perisai'},
];
type InspirationPreset = { key:string; name:string; desc:string; palette:string[]; gradient:string; stops:[string,string,string]; dark:string; bright:string; light:string; emoji:string };
const INSPIRATION_PRESETS: InspirationPreset[] = [
  { key:'gunung', name:'Gunung', desc:'Sejuk, alam, dan tenang — biru langit bertemu hijau pegunungan.', palette:['#38bdf8','#22c55e','#e2f5e9','#14532d','#a3e635'], gradient:'linear-gradient(135deg,#38bdf8 0%,#22c55e 52%,#14532d 100%)', stops:['#38bdf8','#22c55e','#14532d'], dark:'#14532d', bright:'#a3e635', light:'#e2f5e9', emoji:'⛰️' },
  { key:'cafe', name:'Cafe', desc:'Hangat dan akrab — cokelat panggang, karamel, dan krem susu.', palette:['#f59e0b','#78350f','#fef3c7','#451a03','#fbbf24'], gradient:'linear-gradient(135deg,#f59e0b 0%,#78350f 55%,#451a03 100%)', stops:['#f59e0b','#78350f','#451a03'], dark:'#451a03', bright:'#fbbf24', light:'#fef3c7', emoji:'☕' },
  { key:'gaming', name:'Gaming', desc:'Berani dan energik — ungu, pink neon, dan biru elektrik.', palette:['#a855f7','#ec4899','#38bdf8','#0f172a','#f472b6'], gradient:'linear-gradient(135deg,#a855f7 0%,#ec4899 52%,#38bdf8 100%)', stops:['#a855f7','#ec4899','#38bdf8'], dark:'#0f172a', bright:'#f472b6', light:'#e0e7ff', emoji:'🎮' },
];
type Pal = { name:string; c1:string; c2:string; c3?:string };
const PALETTES: Pal[] = [
  {name:'Sunset',c1:'#f97316',c2:'#ec4899',c3:'#facc15'},{name:'Ocean',c1:'#0369a1',c2:'#06b6d4',c3:'#22c55e'},{name:'Forest',c1:'#14532d',c2:'#22c55e',c3:'#a3e635'},{name:'Candy',c1:'#ec4899',c2:'#a855f7',c3:'#38bdf8'},{name:'Galaxy',c1:'#4c1d95',c2:'#7c3aed',c3:'#ec4899'},{name:'Fire',c1:'#dc2626',c2:'#f97316',c3:'#facc15'},{name:'Mint',c1:'#059669',c2:'#34d399',c3:'#a7f3d0'},{name:'Lavender',c1:'#7c3aed',c2:'#c084fc',c3:'#f0abfc'},{name:'Gold Luxury',c1:'#92400e',c2:'#f59e0b',c3:'#fde68a'},{name:'Neon City',c1:'#d946ef',c2:'#22d3ee',c3:'#facc15'},{name:'Ungu-Pink',c1:'#a855f7',c2:'#ec4899',c3:'#f97316'},{name:'Biru-Cyan',c1:'#2563eb',c2:'#06b6d4',c3:'#22c55e'},
  {name:'Rose',c1:'#be185d',c2:'#f472b6',c3:'#fecdd3'},{name:'Peach',c1:'#ea580c',c2:'#fb923c',c3:'#fde68a'},{name:'Sky',c1:'#1d4ed8',c2:'#38bdf8',c3:'#bae6fd'},{name:'Emerald',c1:'#065f46',c2:'#10b981',c3:'#6ee7b7'},{name:'Lemon',c1:'#a16207',c2:'#eab308',c3:'#fef08a'},{name:'Berry',c1:'#701a75',c2:'#c026d3',c3:'#f0abfc'},{name:'Coral',c1:'#c2410c',c2:'#fb7185',c3:'#fda4af'},{name:'Midnight',c1:'#0f172a',c2:'#4338ca',c3:'#38bdf8'},{name:'Aurora',c1:'#059669',c2:'#06b6d4',c3:'#a855f7'},{name:'Sakura',c1:'#db2777',c2:'#f9a8d4',c3:'#fdf2f8'},
  {name:'Coffee',c1:'#451a03',c2:'#92400e',c3:'#fbbf24'},{name:'Matcha',c1:'#365314',c2:'#65a30d',c3:'#d9f99d'},{name:'Grape',c1:'#581c87',c2:'#9333ea',c3:'#e879f9'},{name:'Aqua',c1:'#0e7490',c2:'#22d3ee',c3:'#a5f3fc'},{name:'Ruby',c1:'#881337',c2:'#e11d48',c3:'#fda4af'},{name:'Sapphire',c1:'#1e3a8a',c2:'#3b82f6',c3:'#93c5fd'},{name:'Citrus',c1:'#15803d',c2:'#84cc16',c3:'#fde047'},{name:'Cotton',c1:'#475569',c2:'#94a3b8',c3:'#f8fafc'},
  {name:'Magenta',c1:'#a21caf',c2:'#e879f9',c3:'#f5d0fe'},{name:'Teal Night',c1:'#134e4a',c2:'#14b8a6',c3:'#5eead4'},{name:'Sunrise',c1:'#7c2d12',c2:'#f97316',c3:'#fde68a'},{name:'Indigo Pop',c1:'#312e81',c2:'#6366f1',c3:'#f472b6'},{name:'Jungle',c1:'#14532d',c2:'#16a34a',c3:'#facc15'},{name:'Ice',c1:'#164e63',c2:'#06b6d4',c3:'#e0f2fe'},
];
const BG_OPTIONS = [
  {id:'solid',label:'Warna Solid'},{id:'gradient',label:'Warna Campuran'},{id:'dots',label:'Pola Dots'},{id:'grid',label:'Pola Grid'},{id:'transparent',label:'Transparan'},{id:'black',label:'Hitam'},{id:'white',label:'Putih'},{id:'dark',label:'Hitam Pekat'},{id:'navy',label:'Navy'},{id:'pinksoft',label:'Pink Lembut'},{id:'mintsoft',label:'Mint Lembut'},{id:'sunsetbg',label:'Warna Campuran Sunset'},
];
const STICKERS = ['🔥','⭐','👑','💎','🎮','☕','🚀','💡','🌟','🎵','🍕','🌸'];
const SHAPE_ADD = ['Lingkaran','Persegi','Bintang','Hati','Segitiga'];
const SIMPLE_STYLES = [
  {key:'gaming', label:'Gaming', emoji:'🎮', desc:'Tegas & keren', biz:'Gaming'},
  {key:'cafe', label:'Cafe', emoji:'☕', desc:'Hangat & nyaman', biz:'Cafe'},
  {key:'toko', label:'Toko', emoji:'🛍️', desc:'Ramah & ceria', biz:'Toko Online'},
  {key:'beauty', label:'Beauty', emoji:'💄', desc:'Cantik & lembut', biz:'Beauty'},
  {key:'teknologi', label:'Teknologi', emoji:'💻', desc:'Modern & rapi', biz:'Teknologi'},
  {key:'lucu', label:'Lucu', emoji:'😄', desc:'Lucu & playful', biz:'Lainnya'},
];
const SIMPLE_COLORS = [PALETTES[0], PALETTES[1], PALETTES[3], PALETTES[8], PALETTES[2], PALETTES[12], PALETTES[19], PALETTES[13]];

function hexToHsl(hex:string){ let h=hex.replace('#',''); if(h.length===3) h=h.split('').map(c=>c+c).join(''); const n=parseInt(h,16); const r=((n>>16)&255)/255,g=((n>>8)&255)/255,b=(n&255)/255; const max=Math.max(r,g,b),min=Math.min(r,g,b); let hue=0,sat=0; const l=(max+min)/2; if(max!==min){ const d=max-min; sat=l>0.5?d/(2-max-min):d/(max+min); if(max===r) hue=(g-b)/d+(g<b?6:0); else if(max===g) hue=(b-r)/d+2; else hue=(r-g)/d+4; hue*=60; } return {h:Math.round(hue),s:Math.round(sat*100),l:Math.round(l*100)}; }
function hslToHex(h:number,s:number,l:number){ s/=100;l/=100; const k=(n:number)=> (n+h/30)%12; const a=s*Math.min(l,1-l); const f=(n:number)=> l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1))); const to=(x:number)=> Math.round(x*255).toString(16).padStart(2,'0'); return '#'+to(f(0))+to(f(8))+to(f(4)); }
function mulberry(seed:number){ return function(){ seed|=0; seed=seed+0x6D2B79F5|0; let t=Math.imul(seed^seed>>>15,1|seed); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
function shapeIcon(name:string, size=54){ const p={size,strokeWidth:1.6}; if(name==='Kubus') return <Box {...p}/>; if(name==='Bola') return <Circle {...p}/>; if(name==='Bintang') return <Star {...p}/>; if(name==='Hati') return <Heart {...p}/>; if(name==='Mahkota') return <Crown {...p}/>; return <Shield {...p}/>; }
function extrude(depth:number, style:string, shadow:string, glow:number){
  const parts:string[]=[]; for(let i=1;i<=Math.max(1,Math.round(depth/1.5));i++) parts.push(`${i}px ${i}px 0 ${shadow}`);
  parts.push(`0 22px 38px rgba(0,0,0,.55)`); if(style==='Neon Glow') parts.push(`0 0 ${glow}px #ec4899, 0 0 ${glow*2}px #a855f7`);
  return parts.join(',');
}
function bgStyle(d:Design, inspiration:any=null, mode:any='none', transp=25, bright=100):React.CSSProperties{
  if(d.transparent || d.bgMode==='transparent') return {background:'repeating-conic-gradient(#3b345a 0% 25%, #241d44 0% 50%) 0 0 / 28px 28px'};
  if(d.bgMode==='dots') return {backgroundColor:d.bg, backgroundImage:'radial-gradient(rgba(255,255,255,.22) 1.5px, transparent 1.5px)', backgroundSize:'22px 22px'};
  if(d.bgMode==='grid') return {backgroundColor:d.bg, backgroundImage:'linear-gradient(rgba(255,255,255,.12) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.12) 1px, transparent 1px)', backgroundSize:'26px 26px'};
  if(d.bgMode==='gradient') return {background:`linear-gradient(135deg, ${d.bg}, ${d.color2}, ${d.color})`};
  if(d.bgMode==='black') return {background:'#000000'};
  if(d.bgMode==='white') return {background:'#ffffff'};
  if(d.bgMode==='dark') return {background:'#070414'};
  if(d.bgMode==='navy') return {background:'#0f172a'};
  if(d.bgMode==='pinksoft') return {background:'#fdf2f8'};
  if(d.bgMode==='mintsoft') return {background:'#ecfdf5'};
  if(d.bgMode==='sunsetbg') return {background:'linear-gradient(135deg,#f97316,#ec4899,#7c3aed)'};
  return {background:d.bg};
}
function Preview({d, mini=false, inspiration=null, inspirationMode='none', inspirationTransparency=25, inspirationBrightness=100}:{d:Design;mini?:boolean; inspiration?:InspirationPreset|null; inspirationMode?:'none'|'background'|'watermark'; inspirationTransparency?:number; inspirationBrightness?:number}){
  const anim = d.anim==='Putar' ? 'spin3d 7s linear infinite' : d.anim==='Melayang' ? 'levitate 3.2s ease-in-out infinite' : d.anim==='Memantul' ? 'bounceLogo 2.2s ease-in-out infinite' : 'none';
  const grad = d.gradient==='Custom' ? `linear-gradient(135deg, ${d.color}, ${d.color2})` : (GRADIENTS[d.gradient] || GRADIENTS['Ungu-Pink']);
  const showText = d.style==='Warna Campuran' ? {background:grad,WebkitBackgroundClip:'text',backgroundClip:'text',color:'transparent'} : {color: d.style==='Neon Glow' ? '#fff' : d.color};
  const showOverlay = !!inspiration && inspirationMode!=='none' && !mini;
  const overlayOpacity = Math.max(0, Math.min(1, (100 - inspirationTransparency) / 100));
  return <div className="relative w-full h-full flex items-center justify-center overflow-hidden" style={{...bgStyle(d), borderRadius: mini?18:0}}>
    {showOverlay && inspirationMode==='background' && <div className="absolute inset-0" style={{background: inspiration!.gradient, opacity: overlayOpacity, filter:`brightness(${inspirationBrightness}%)`}} />}
    {showOverlay && inspirationMode==='watermark' && <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[74%] h-[62%] rounded-full" style={{background: inspiration!.gradient, opacity: overlayOpacity * 0.45, filter:`brightness(${inspirationBrightness}%) blur(2px)`}} />}
    <div className="absolute inset-0 opacity-25" style={{background:'radial-gradient(circle at 30% 20%, rgba(236,72,153,.45), transparent 42%), radial-gradient(circle at 75% 80%, rgba(56,189,248,.35), transparent 45%)'}} />
    <div style={{transform:`perspective(900px) rotateX(${d.rotX}deg) rotateY(${d.rotY}deg) skewX(${d.tilt}deg)`, transformStyle:'preserve-3d', animation:anim}} className="relative z-10 text-center px-3 min-w-0">
      <div className={`mx-auto mb-2 flex items-center justify-center ${d.style==='Kaca / Glass' ? 'bg-white/15 backdrop-blur-md border border-white/30 rounded-full' : ''}`} style={{width:mini?66:104,height:mini?66:104, color: d.style==='Metalik' ? '#fde68a' : '#f472b6', filter:`drop-shadow(0 12px 18px rgba(0,0,0,.35)) drop-shadow(0 0 ${d.glow/2}px ${d.color2})`}}>{shapeIcon(d.shape, mini?34:58)}</div>
      <div className={d.anim==='Berkilau' ? 'shine' : ''} style={{fontFamily:FONTS[d.font], fontWeight:900, fontSize: mini? Math.min(26, d.size*0.32): d.size, lineHeight:1.05, letterSpacing: d.font==='Bebas'?'.08em':'-.02em', textShadow: extrude(d.depth,d.style,d.shadowColor,d.glow), whiteSpace: mini?'normal':'nowrap', wordBreak:'break-word', overflowWrap:'anywhere', maxWidth:'100%', ...showText}}>{d.text || 'BRANDKU'}</div>
      <div className="mt-2 text-[10px] sm:text-xs tracking-[.35em] font-bold text-white/80">• EST. 2026 • GRATIS •</div>
    </div>
  </div>
}
async function api(action:string, args:any){ const res=await fetch("actions",{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action,args})}); const j=await res.json(); if(!res.ok||j.error) throw new Error(j.error||'Layanan belum tersedia'); return j.data; }
function copyTextToClipboard(text:string, done:(ok:boolean)=>void){ const ta=document.createElement('textarea'); ta.value=text; ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta); ta.select(); try{ document.execCommand('copy'); done(true); }catch{ done(false); } document.body.removeChild(ta); }
function Accordion({title, icon, open, onToggle, children}:{title:string; icon:React.ReactNode; open:boolean; onToggle:()=>void; children:React.ReactNode}){
  return <section className="rounded-2xl border border-white/10 bg-white/[.03] overflow-hidden">
    <button type="button" onClick={onToggle} aria-expanded={open} className="w-full min-h-[52px] px-4 py-3 flex items-center justify-between gap-3 text-left font-bold text-base hover:bg-white/5">
      <span className="flex items-center gap-2 min-w-0">{icon}<span className="truncate">{title}</span></span>
      <ChevronDown size={18} className={`shrink-0 transition-transform ${open?'rotate-180':''}`} />
    </button>
    {open && <div className="px-4 pb-4 pt-1">{children}</div>}
  </section>
}
type Layer = { id:string; kind:'text'|'shape'|'sticker'|'image'; label:string; content:string; x:number; y:number; size:number; rotation:number; opacity:number; visible:boolean; color:string; font:string };
const uid = ()=> 'L'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);

export default function App(){
  const [splash,setSplash]=useState(true); const [design,setDesign]=useState<Design>(DEFAULTS); const [saved,setSaved]=useState<any[]>([]); const [saveMsg,setSaveMsg]=useState(''); const [copyMsg,setCopyMsg]=useState(''); const [dlMsg,setDlMsg]=useState(''); const [busy,setBusy]=useState(false); const [openSaved,setOpenSaved]=useState(false); const [menuOpen,setMenuOpen]=useState(false);
  const [openSections,setOpenSections]=useState<Record<string,boolean>>({teks:true,warna:true,dimensi:true,bentuk:true,gaya:true,warnaPro:true,ai:true,canvas:true});
  const previewRef=useRef<HTMLDivElement>(null);
  const set = (patch:Partial<Design>)=> setDesign(v=>({...v,...patch}));
  const toggleSection=(k:string)=> setOpenSections(v=>({...v,[k]:!v[k]}));
  const [presetKey,setPresetKey]=useState<string|null>(null);
  const [inspirationMode,setInspirationMode]=useState<'none'|'background'|'watermark'>('none');
  const [inspirationTransparency,setInspirationTransparency]=useState(25);
  const [inspirationBrightness,setInspirationBrightness]=useState(100);
  const [variation,setVariation]=useState<string|null>(null);
  const [inspirationMsg,setInspirationMsg]=useState('');
  const inspiration = useMemo(()=> INSPIRATION_PRESETS.find(p=>p.key===presetKey) || null, [presetKey]);
  // SIMPLE MODE
  const [simpleMode,setSimpleMode]=useState(true);
  const [simpleStyleKey,setSimpleStyleKey]=useState<string|null>(null);
  const [simpleColorChosen,setSimpleColorChosen]=useState(false);
  const [simpleMsg,setSimpleMsg]=useState('');
  const [showSimpleChoices,setShowSimpleChoices]=useState(false);
  const [simplePhotoMsg,setSimplePhotoMsg]=useState('');
  useEffect(()=>{ const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting) e.target.classList.add('is-visible')}),{threshold:.12}); document.querySelectorAll('.reveal').forEach(el=>io.observe(el)); return ()=>io.disconnect(); },[splash,simpleMode]);
  const loadSaved=async()=>{ try{ const data=await api("records.list",{collection:'saved-logos'}); setSaved(data.records||[]); }catch{ setSaved([]); } };
  useEffect(()=>{ loadSaved(); loadFavs(); },[]);

  const [hex1,setHex1]=useState('#ffffff'); const [hex2,setHex2]=useState('#ec4899');
  const [favPalettes,setFavPalettes]=useState<any[]>([]); const [favMsg,setFavMsg]=useState(''); const [colorMsg,setColorMsg]=useState('');
  useEffect(()=>{ setHex1(design.color); setHex2(design.color2); },[design.color,design.color2]);
  const loadFavs=async()=>{ try{ const d=await api("records.list",{collection:'favorite-palettes'}); setFavPalettes(d.records||[]); }catch{ setFavPalettes([]); } };
  const hsl1=useMemo(()=>hexToHsl(design.color),[design.color]); const hsl2=useMemo(()=>hexToHsl(design.color2),[design.color2]);
  const setHsl=(which:1|2, patch:Partial<{h:number;s:number;l:number}>)=>{ const cur=which===1?hsl1:hsl2; const next={...cur,...patch}; const hex=hslToHex(next.h,next.s,next.l); if(which===1) set({color:hex, gradient:'Custom'}); else set({color2:hex, gradient:'Custom'}); };
  const applyPalette=(p:Pal)=>{ set({color:p.c1,color2:p.c2,gradient:'Custom'}); setColorMsg(`Palet ${p.name} dipakai — ${p.c1} → ${p.c2}.`); };
  const randomColor=()=>{ const r=mulberry(Date.now()); const p=PALETTES[Math.floor(r()*PALETTES.length)]; applyPalette(p); set({shadowColor:'#'+Math.floor(r()*16777215).toString(16).padStart(6,'0'), glow:10+Math.floor(r()*50)}); };
  const saveFav=async()=>{ setFavMsg(''); try{ const key=`pal-${Date.now()}-${Math.random().toString(36).slice(2,6)}`; await api("records.create",{collection:'favorite-palettes',value:{name:`Palet ${favPalettes.length+1}`,c1:design.color,c2:design.color2,shadow:design.shadowColor,glow:design.glow,createdAt:new Date().toISOString()},idempotency_key:key}); await loadFavs(); setFavMsg('Palet favorit tersimpan.'); }catch(e:any){ setFavMsg(e.message||'Penyimpanan belum tersedia di pratinjau.'); } };
  const deleteFav=async(id:string)=>{ try{ await api("records.delete",{collection:'favorite-palettes',id}); await loadFavs(); }catch{ setFavMsg('Gagal menghapus palet.'); } };

  const [aiBrand,setAiBrand]=useState('BRANDKU'); const [aiBiz,setAiBiz]=useState('Gaming'); const [aiStyle,setAiStyle]=useState('Bold'); const [aiSeed,setAiSeed]=useState(1); const [aiNames,setAiNames]=useState<string[]>([]); const [aiTaglines,setAiTaglines]=useState<string[]>([]); const [aiMsg,setAiMsg]=useState('');
  const BIZ_MAP:Record<string,{colors:Pal[];fonts:string[];shapes:string[];styles:string[]}> = {
    Gaming:{colors:[PALETTES[3],PALETTES[9],PALETTES[5],PALETTES[10]],fonts:['Montserrat ExtraBold','Bebas','Poppins Bold'],shapes:['Perisai','Mahkota','Kubus'],styles:['Neon Glow','Warna Campuran']},
    Cafe:{colors:[PALETTES[22],PALETTES[8],PALETTES[13],PALETTES[12]],fonts:['Playfair','Poppins Bold'],shapes:['Bola','Hati','Bintang'],styles:['Metalik','Matte']},
    'Toko Online':{colors:[PALETTES[0],PALETTES[3],PALETTES[2],PALETTES[21]],fonts:['Poppins Bold','Montserrat ExtraBold'],shapes:['Hati','Bintang','Bola'],styles:['Warna Campuran','Matte']},
    Beauty:{colors:[PALETTES[7],PALETTES[12],PALETTES[21],PALETTES[30]],fonts:['Playfair','Poppins Bold'],shapes:['Bintang','Hati','Bola'],styles:['Kaca / Glass','Warna Campuran']},
    Teknologi:{colors:[PALETTES[1],PALETTES[11],PALETTES[19],PALETTES[25]],fonts:['Monospace','Montserrat ExtraBold'],shapes:['Kubus','Bola','Perisai'],styles:['Metalik','Warna Campuran']},
    Musik:{colors:[PALETTES[4],PALETTES[0],PALETTES[9]],fonts:['Bebas','Poppins Bold'],shapes:['Bola','Bintang','Hati'],styles:['Neon Glow','Warna Campuran']},
    Pendidikan:{colors:[PALETTES[2],PALETTES[1],PALETTES[15]],fonts:['Montserrat ExtraBold','Poppins Bold'],shapes:['Perisai','Kubus','Bintang'],styles:['Matte','Warna Campuran']},
    Lainnya:{colors:PALETTES.slice(0,8),fonts:['Poppins Bold','Montserrat ExtraBold','Playfair'],shapes:SHAPES,styles:STYLES},
  };
  type Sug={name:string;font:string;shape:string;style:string;c1:string;c2:string;depth:number;rotY:number};
  const suggestions: Sug[] = useMemo(()=>{
    const biz=BIZ_MAP[aiBiz]||BIZ_MAP.Lainnya; const rnd=mulberry(aiSeed*997+aiBiz.length*13+aiStyle.length*7);
    const styleBoost = aiStyle==='Elegan'?{depth:10}: aiStyle==='Bold'?{depth:28}: aiStyle==='Minimalis'?{depth:6}: aiStyle==='Playful'?{depth:20}:{depth:16};
    return Array.from({length:6},(_,i)=>{
      const p=biz.colors[Math.floor(rnd()*biz.colors.length)]; const font=biz.fonts[Math.floor(rnd()*biz.fonts.length)]; const shape=biz.shapes[Math.floor(rnd()*biz.shapes.length)]; const style=biz.styles[Math.floor(rnd()*biz.styles.length)];
      return {name:`${aiStyle} ${aiBiz} ${i+1}`,font,shape,style,c1:p.c1,c2:p.c2,depth:Math.max(4,styleBoost.depth+Math.floor(rnd()*10)-5),rotY:Math.floor(rnd()*40)-20};
    });
  },[aiSeed,aiBiz,aiStyle]);
  const genNamesTaglines=()=>{ const b=(aiBrand||'Brand').trim()||'Brand'; const caps=b.charAt(0).toUpperCase()+b.slice(1).toLowerCase();
    setAiNames([caps+'ku',caps+' Studio',caps+' & Co',caps+' Lab',caps+' Nusantara']); setAiTaglines([`${caps} — dibuat untuk menang.`,'Rasa yang diingat, brand yang dicintai.',`${caps}: kecil di nama, besar di karya.`,'Desain berani untuk brand berani.','Satu nama, seribu cerita baik.']); setAiMsg('5 nama & 5 tagline baru dibuat. Klik untuk memakai.'); };
  const applySuggestion=(s:Sug)=>{ const txt=(aiBrand||design.text||'BRANDKU').toUpperCase(); set({text:txt,font:s.font,shape:s.shape,style:s.style,color:s.c1,color2:s.c2,gradient:'Custom',depth:s.depth,rotY:s.rotY}); setLayers(ls=>ls.map(l=> l.kind==='text'?{...l,content:txt,color:s.c1,font:s.font}: l.kind==='shape'?{...l,content:s.shape,color:s.c2}:l)); setAiMsg(`Desain “${s.name}” diterapkan ke editor & canvas.`); setSimpleMsg(`Pilihan “${s.name}” dipakai. Tinggal download!`); document.getElementById('editor')?.scrollIntoView({behavior:'smooth'}); };

  const [layers,setLayers]=useState<Layer[]>(()=>[
    {id:uid(),kind:'text',label:'Teks Utama',content:'BRANDKU',x:50,y:42,size:72,rotation:-4,opacity:1,visible:true,color:'#ffffff',font:'Poppins Bold'},
    {id:uid(),kind:'shape',label:'Bentuk',content:'Bintang',x:50,y:20,size:64,rotation:0,opacity:1,visible:true,color:'#f472b6',font:'Poppins Bold'},
    {id:uid(),kind:'sticker',label:'Stiker',content:'⭐',x:78,y:24,size:44,rotation:12,opacity:1,visible:true,color:'#ffffff',font:'Poppins Bold'},
  ]);
  const [selectedId,setSelectedId]=useState<string|null>(null);
  const [past,setPast]=useState<Layer[][]>([]); const [future,setFuture]=useState<Layer[][]>([]);
  const [zoom,setZoom]=useState(100); const [canvasMsg,setCanvasMsg]=useState('');
  const canvasRef=useRef<HTMLDivElement>(null); const dragRef=useRef<any>(null);
  const selected = layers.find(l=>l.id===selectedId)||null;
  const pushHistory=(next:Layer[])=>{ setPast(p=>[...p.slice(-29),layers]); setFuture([]); setLayers(next); };
  const undo=()=>{ if(!past.length) return; const prev=past[past.length-1]; setFuture(f=>[layers,...f]); setPast(p=>p.slice(0,-1)); setLayers(prev); };
  const redo=()=>{ if(!future.length) return; const nxt=future[0]; setPast(p=>[...p,layers]); setFuture(f=>f.slice(1)); setLayers(nxt); };
  const updateLayer=(id:string,patch:Partial<Layer>)=>{ setLayers(ls=>ls.map(l=>l.id===id?{...l,...patch}:l)); };
  const onLayerPointerDown=(e:React.PointerEvent,l:Layer,mode:'move'|'resize'|'rotate')=>{ e.preventDefault(); e.stopPropagation(); setSelectedId(l.id); const rect=canvasRef.current?.getBoundingClientRect(); if(!rect) return; const cx=rect.left+(l.x/100)*rect.width, cy=rect.top+(l.y/100)*rect.height; dragRef.current={id:l.id,mode,startX:e.clientX,startY:e.clientY,startLayer:{...l},cx,cy,startAngle:Math.atan2(e.clientY-cy,e.clientX-cx)}; (e.target as HTMLElement).setPointerCapture?.(e.pointerId); };
  const onCanvasPointerMove=(e:React.PointerEvent)=>{ const d=dragRef.current; if(!d) return; const rect=canvasRef.current?.getBoundingClientRect(); if(!rect) return; const l=layers.find(x=>x.id===d.id); if(!l) return;
    if(d.mode==='move'){ const dx=(e.clientX-d.startX)/rect.width*100, dy=(e.clientY-d.startY)/rect.height*100; updateLayer(d.id,{x:Math.max(5,Math.min(95,d.startLayer.x+dx)), y:Math.max(5,Math.min(95,d.startLayer.y+dy))}); }
    if(d.mode==='resize'){ const dist=Math.hypot(e.clientX-d.cx,e.clientY-d.cy); const startDist=Math.hypot(d.startX-d.cx,d.startY-d.cy)||80; updateLayer(d.id,{size:Math.max(20,Math.min(180, d.startLayer.size*(dist/startDist)))}); }
    if(d.mode==='rotate'){ const ang=Math.atan2(e.clientY-d.cy,e.clientX-d.cx); const delta=(ang-d.startAngle)*180/Math.PI; updateLayer(d.id,{rotation:Math.round(d.startLayer.rotation+delta)}); }
  };
  const endDrag=()=>{ if(dragRef.current){ setPast(p=>[...p.slice(-29),layers]); setFuture([]); dragRef.current=null; } };
  const addText=()=>{ const l:Layer={id:uid(),kind:'text',label:'Teks Baru',content:design.text||'TEKS BARU',x:50,y:55,size:48,rotation:0,opacity:1,visible:true,color:design.color,font:design.font}; pushHistory([...layers,l]); setSelectedId(l.id); setCanvasMsg('Teks baru ditambahkan — tarik untuk memindah.'); };
  const addShape=(s:string)=>{ const l:Layer={id:uid(),kind:'shape',label:`Bentuk ${s}`,content:s,x:50,y:50,size:60,rotation:0,opacity:1,visible:true,color:design.color2,font:design.font}; pushHistory([...layers,l]); setSelectedId(l.id); };
  const addSticker=(em:string)=>{ const l:Layer={id:uid(),kind:'sticker',label:'Stiker',content:em,x:50,y:50,size:44,rotation:0,opacity:1,visible:true,color:'#fff',font:design.font}; pushHistory([...layers,l]); setSelectedId(l.id); };
  const moveLayer=(id:string,dir:1|-1)=>{ const idx=layers.findIndex(l=>l.id===id); const ni=idx+dir; if(idx<0||ni<0||ni>=layers.length) return; const next=[...layers]; [next[idx],next[ni]]=[next[ni],next[idx]]; pushHistory(next); };
  const duplicateLayer=(l:Layer)=>{ const c={...l,id:uid(),x:Math.min(90,l.x+6),y:Math.min(90,l.y+6),label:l.label+' (Salinan)'}; pushHistory([...layers,c]); setSelectedId(c.id); };
  const deleteLayer=(id:string)=>{ pushHistory(layers.filter(l=>l.id!==id)); if(selectedId===id) setSelectedId(null); };
  const align=(kind:'left'|'center'|'right')=>{ if(!selected) { setCanvasMsg('Pilih satu lapisan dulu, lalu pakai Rata.'); return; } const x=kind==='left'?14:kind==='center'?50:86; updateLayer(selected.id,{x}); setCanvasMsg(`Lapisan rata ${kind==='left'?'kiri':kind==='center'?'tengah':'kanan'}.`); };
  const renderLayerContent=(l:Layer, scale=1)=>{ if(l.kind==='text') return <span style={{fontFamily:FONTS[l.font]||FONTS['Poppins Bold'],fontWeight:900, fontSize:l.size*scale, lineHeight:1, color:l.color, textShadow:`2px 2px 0 ${design.shadowColor}`, whiteSpace:'nowrap'}}>{l.content}</span>;
    if(l.kind==='sticker') return <span style={{fontSize:l.size*scale,lineHeight:1}}>{l.content}</span>;
    if(l.kind==='image') return <span style={{fontSize:l.size*scale}}>🖼️</span>;
    const s=l.size*scale; const common={width:s,height:s,color:l.color}; if(l.content==='Lingkaran') return <div style={{...common,borderRadius:'50%',border:`4px solid ${l.color}`}}/>; if(l.content==='Persegi') return <div style={{...common,border:`4px solid ${l.color}`,borderRadius:10}}/>; if(l.content==='Segitiga') return <div style={{width:0,height:0,borderLeft:`${s/2}px solid transparent`,borderRight:`${s/2}px solid transparent`,borderBottom:`${s}px solid ${l.color}`}}/>; if(l.content==='Hati') return <Heart size={s} fill={l.color} color={l.color}/>; if(l.content==='Bintang') return <Star size={s} fill={l.color} color={l.color}/>; return <div style={{width:s,height:s}}>{shapeIcon(design.shape,s)}</div>; };

  const applyTemplate=(t:typeof TEMPLATES[number])=>{ set({...t.d}); document.getElementById('editor')?.scrollIntoView({behavior:'smooth'}); };
  const randomize=()=>{ const gs=Object.keys(GRADIENTS); const fs=Object.keys(FONTS); set({gradient:gs[Math.floor(Math.random()*gs.length)], font:fs[Math.floor(Math.random()*fs.length)], shape:SHAPES[Math.floor(Math.random()*SHAPES.length)], style:STYLES[Math.floor(Math.random()*STYLES.length)], rotY:Math.floor(Math.random()*50)-25, rotX:Math.floor(Math.random()*24), depth:8+Math.floor(Math.random()*26), size:58+Math.floor(Math.random()*38)}); };
  const reset=()=>setDesign(DEFAULTS);
  const copyText=()=>{ copyTextToClipboard(design.text,(ok)=>setCopyMsg(ok?'Nama logo tersalin!':'Gagal menyalin. Silakan ketik ulang.')); setTimeout(()=>setCopyMsg(''),2600); };
  const download=()=>{ setDlMsg('Menggambar PNG…'); const c=document.createElement('canvas'); c.width=1200; c.height=760; const x=c.getContext('2d'); if(!x) return; x.fillStyle=design.transparent?'#ffffff':design.bg; x.fillRect(0,0,1200,760);
    if(design.bgMode==='gradient'){ const g=x.createLinearGradient(0,0,1200,760); g.addColorStop(0,design.bg); g.addColorStop(.5,design.color2); g.addColorStop(1,design.color); x.fillStyle=g; x.fillRect(0,0,1200,760); }
    if(design.bgMode==='dots'){ x.fillStyle='rgba(255,255,255,.25)'; for(let yy=15;yy<760;yy+=28) for(let xx=15;xx<1200;xx+=28){ x.beginPath(); x.arc(xx,yy,2.5,0,Math.PI*2); x.fill(); } }
    if(design.bgMode==='grid'){ x.strokeStyle='rgba(255,255,255,.14)'; x.lineWidth=1; for(let xx=0;xx<1200;xx+=32){ x.beginPath(); x.moveTo(xx,0); x.lineTo(xx,760); x.stroke(); } for(let yy=0;yy<760;yy+=32){ x.beginPath(); x.moveTo(0,yy); x.lineTo(1200,yy); x.stroke(); } }
    if(inspiration && inspirationMode!=='none'){ const alpha=Math.max(0,Math.min(1,(100-inspirationTransparency)/100)); x.save(); try{ (x as any).filter=`brightness(${inspirationBrightness}%)`; }catch{} if(inspirationMode==='background'){ x.globalAlpha=alpha; const ig=x.createLinearGradient(0,0,1200,760); ig.addColorStop(0,inspiration.stops[0]); ig.addColorStop(.52,inspiration.stops[1]); ig.addColorStop(1,inspiration.stops[2]); x.fillStyle=ig; x.fillRect(0,0,1200,760); } else { x.globalAlpha=alpha*0.45; const ig=x.createLinearGradient(200,150,1000,610); ig.addColorStop(0,inspiration.stops[0]); ig.addColorStop(.5,inspiration.stops[1]); ig.addColorStop(1,inspiration.stops[2]); x.fillStyle=ig; x.beginPath(); x.ellipse(600,380,360,230,0,0,Math.PI*2); x.fill(); } x.restore(); try{ (x as any).filter='none'; }catch{} x.globalAlpha=1; }
    [...layers].forEach(l=>{ if(!l.visible) return; const px=l.x/100*1200, py=l.y/100*760; x.save(); x.globalAlpha=l.opacity; x.translate(px,py); x.rotate(l.rotation*Math.PI/180); x.textAlign='center'; x.textBaseline='middle';
      if(l.kind==='text'){ x.font=`900 ${l.size*2.1}px ${FONTS[l.font]||FONTS['Poppins Bold']}`; x.fillStyle=design.shadowColor; x.fillText(l.content,4,6); if(design.style==='Warna Campuran'){ const tg=x.createLinearGradient(-260,0,260,0); tg.addColorStop(0,l.color); tg.addColorStop(1,design.color2); x.fillStyle=tg; } else x.fillStyle=l.color; x.fillText(l.content,0,0); }
      else if(l.kind==='sticker'){ x.font=`${l.size*2.1}px Poppins, sans-serif`; x.fillText(l.content,0,0); }
      else if(l.kind==='shape'){ x.fillStyle=l.color; const s=l.size*1.8; if(l.content==='Lingkaran'){ x.beginPath(); x.arc(0,0,s/2,0,Math.PI*2); x.fill(); } else if(l.content==='Persegi'){ x.fillRect(-s/2,-s/2,s,s); } else if(l.content==='Segitiga'){ x.beginPath(); x.moveTo(0,-s/2); x.lineTo(s/2,s/2); x.lineTo(-s/2,s/2); x.closePath(); x.fill(); } else { x.font=`900 ${s}px Poppins, sans-serif`; x.fillText('★',0,0); } }
      x.restore(); });
    x.font='700 28px Poppins, sans-serif'; x.fillStyle='rgba(255,255,255,.9)'; x.textAlign='center'; x.fillText('DIBUAT GRATIS • LOGO3D GRATIS',600,720); const a=document.createElement('a'); a.download=`logo-3d-${(design.text||'brandku').toLowerCase().replace(/[^a-z0-9]+/g,'-')}.png`; a.href=c.toDataURL('image/png'); document.body.appendChild(a); a.click(); a.remove(); setDlMsg('PNG berhasil diunduh — posisi lapisan ikut tersimpan!'); setTimeout(()=>setDlMsg(''),3000); };
  const saveDesign=async()=>{ setBusy(true); setSaveMsg(''); try{ const key=`logo-${Date.now()}-${Math.random().toString(36).slice(2,8)}`; await api("records.create",{collection:'saved-logos',value:{...design,layers,savedAt:new Date().toISOString()},idempotency_key:key}); await loadSaved(); setSaveMsg('Desain + lapisan tersimpan di galeri kamu.'); }catch(e:any){ setSaveMsg(e.message||'Penyimpanan belum tersedia di pratinjau.'); } finally{ setBusy(false); setTimeout(()=>setSaveMsg(''),3200); } };
  const deleteSaved=async(id:string)=>{ try{ await api("records.delete",{collection:'saved-logos',id}); await loadSaved(); }catch{ setSaveMsg('Gagal menghapus desain.'); } };
  const go=(id:string)=>{ setMenuOpen(false); document.getElementById(id)?.scrollIntoView({behavior:'smooth'}); };
  const choosePreset=(p:InspirationPreset)=>{ setPresetKey(p.key); setVariation(null); setInspirationMode('none'); setInspirationMsg(`Inspirasi ${p.name} dipilih — palet warnanya siap dipakai.`); };
  const applySwatch=(color:string)=>{ if(!inspiration){ setInspirationMsg('Pilih salah satu inspirasi contoh dulu, lalu klik swatch-nya.'); return; } set({color, style:'Matte'}); setInspirationMsg(`Warna logo diubah ke ${color}.`); };
  const applyVariation=(kind:'asli'|'neon'|'elegan')=>{ if(!inspiration){ setInspirationMsg('Pilih salah satu inspirasi contoh dulu untuk membuat 3 variasi ini.'); return; } setVariation(kind); if(kind==='asli'){ set({color:inspiration.palette[0], style:'Matte', bg:'#17102f'}); setInspirationMsg('Variasi “Warna Asli” diterapkan — warna dominan jadi warna teks.'); } else if(kind==='neon'){ set({color:inspiration.bright, style:'Neon Glow', bg:'#0a061a'}); setInspirationMsg('Variasi “Neon dari Gambar” diterapkan — warna paling cerah + glow neon.'); } else { set({color:inspiration.light, style:'Matte', bg:inspiration.dark}); setInspirationMsg('Variasi “Elegan / Matte” diterapkan — latar gelap + warna lembut.'); } };
  const useAsBackground=()=>{ if(!inspiration){ setInspirationMsg('Pilih salah satu inspirasi contoh dulu, lalu tekan “Jadikan Background Logo”.'); return; } setInspirationMode('background'); setInspirationMsg('Inspirasi dipakai sebagai background logo. Atur transparansinya di slider.'); };
  const useAsWatermark=()=>{ if(!inspiration){ setInspirationMsg('Pilih salah satu inspirasi contoh dulu, lalu tekan “Jadikan Bentuk / Watermark”.'); return; } setInspirationMode('watermark'); setInspirationMsg('Inspirasi dipakai sebagai watermark lembut di belakang teks.'); };
  const clearInspiration=()=>{ setPresetKey(null); setInspirationMode('none'); setVariation(null); setInspirationMsg('Inspirasi dihapus — logo kembali ke pengaturan editor.'); };

  // ---------- SIMPLE HELPERS ----------
  const brandFilled = design.text.trim().length>0 && design.text.trim().toUpperCase()!=='BRANDKU';
  const completedCount = (brandFilled?1:0)+(simpleStyleKey?1:0)+(simpleColorChosen?1:0);
  const progressPct = Math.round(completedCount/3*100);
  const currentStep = completedCount>=3?3:completedCount+1;
  const applySimpleStyle=(item:typeof SIMPLE_STYLES[number])=>{
    setSimpleStyleKey(item.key); setAiBiz(item.biz); setAiStyle(item.key==='lucu'?'Playful':item.key==='cafe'?'Elegan':'Bold');
    const biz=BIZ_MAP[item.biz]||BIZ_MAP.Lainnya; const pick=biz.colors[0]; const font=biz.fonts[0]; const shape=biz.shapes[0]; const style=biz.styles[0];
    const txt=(design.text||'BRANDKU').toUpperCase();
    set({font,shape,style,color:pick.c1,color2:pick.c2,gradient:'Custom'});
    setLayers(ls=>ls.map(l=> l.kind==='text'?{...l,content:txt,color:pick.c1,font}: l.kind==='shape'?{...l,content:shape,color:pick.c2}:l));
    setSimpleMsg(`Gaya ${item.label} dipakai! Lihat logomu berubah di samping.`);
  };
  const applySimpleColor=(p:Pal)=>{ set({color:p.c1,color2:p.c2,gradient:'Custom'}); setSimpleColorChosen(true); setSimpleMsg(`Warna ${p.name} dipakai — cakep!`); };
  const handleConfused=()=>{ randomize(); const item=SIMPLE_STYLES[Math.floor(Math.random()*SIMPLE_STYLES.length)]; setSimpleStyleKey(item.key); setAiBiz(item.biz); setSimpleColorChosen(true); genNamesTaglines(); setSimpleMsg(`Tenang! Kami buatkan logo ${item.label} yang bagus buat kamu. Kalau belum suka, klik lagi ya.`); };
  const handleMakeLogo=()=>{ if(!brandFilled){ setSimpleMsg('Ketik dulu nama brand kamu di Langkah 1 ya — contoh: Kopi Kita.'); document.getElementById('simple-brand')?.focus(); return; } if(!simpleStyleKey){ setSimpleMsg('Pilih dulu 1 gaya di Langkah 2 ya, yang paling mirip usahamu.'); return; } setSimpleMsg(`Yeay! Logo “${design.text}” sudah jadi. Tinggal download di bawah!`); document.getElementById('preview-simple')?.scrollIntoView({behavior:'smooth',block:'center'}); };
  const handleShowChoices=()=>{ if(!simpleStyleKey){ setSimpleMsg('Pilih dulu 1 gaya di Langkah 2, baru kami carikan 6 pilihan lainnya.'); return; } setAiSeed(s=>s+1); genNamesTaglines(); setShowSimpleChoices(true); setSimpleMsg('Ini 6 pilihan lainnya buat kamu — klik salah satu yang paling kamu suka!'); };
  const handleSimplePhoto=()=>{ setSimplePhotoMsg('Unggah foto dan file belum tersedia untuk saat ini. Aplikasi ini belum bisa menerima foto dari perangkatmu. Coba 3 contoh inspirasi di bawah ya — warnanya langsung nempel ke logo.'); };
  const handleSimpleBrand=(v:string)=>{ const clean=v.slice(0,18); set({text:clean}); setAiBrand(clean||'BRANDKU'); setLayers(ls=>ls.map(l=> l.kind==='text'?{...l,content:(clean||'BRANDKU').toUpperCase()}:l)); };

  const letters='Buat Logo 3D Impianmu'.split('');
  return <div data-safe-area-inset-root style={{boxSizing:'border-box',paddingTop:'var(--safe-area-inset-top)'}} className="min-h-screen bg-[var(--bg)] text-[var(--text)] overflow-x-clip relative">
  {splash && <div className="fixed inset-0 z-50 bg-[#0a061a] overflow-hidden flex flex-col items-center justify-center px-5 text-center">
    <div className="orb w-72 h-72 bg-purple-600 left-[-70px] top-[10%]" /><div className="orb w-64 h-64 bg-pink-500 right-[-60px] bottom-[12%]" style={{animationDelay:'1.2s'}} />
    {Array.from({length:14}).map((_,i)=><span key={i} className="absolute rounded-full bg-white/80" style={{width:5+(i%3)*4,height:5+(i%3)*4,left:`${(i*67)%92}%`,bottom:'8%',animation:`particle ${3+i%4}s linear ${i*.25}s infinite`}} />)}
    {['#f472b6','#a78bfa','#38bdf8','#fbbf24'].map((c,i)=><span key={c} className="absolute w-3 h-4 rounded-[2px]" style={{background:c,left:`${12+i*24}%`,top:'-20px',animation:`confettiFall ${2.8+i*.35}s ease-in ${i*.3}s infinite`}} />)}
    <div className="relative z-10">
      <div className="mx-auto w-32 h-32 sm:w-40 sm:h-40 mb-6" style={{animation:'spin3d 4s linear infinite',transformStyle:'preserve-3d'}}><div className="w-full h-full rounded-[28px] bg-gradient-to-br from-violet-600 via-pink-500 to-sky-400 flex items-center justify-center shadow-[0_25px_60px_rgba(236,72,153,.45)]"><span className="text-6xl sm:text-7xl font-black">3D</span></div></div>
      <p className="text-pink-300 font-bold tracking-[.3em] text-xs mb-3">LOGO3D GRATIS • AI PRO • TANPA WATERMARK</p>
      <h1 className="text-[clamp(2rem,8vw,4.2rem)] leading-[1.02] font-black">{letters.map((ch,i)=><span key={i} className="letter" style={{animationDelay:`${i*0.035}s`}}>{ch===' ' ? '\u00A0':ch}</span>)}</h1>
      <p className="mt-4 text-white/70 max-w-md mx-auto">Cuma 3 langkah: ketik nama, pilih gaya, pilih warna. Logo langsung jadi — gratis!</p>
      <button onClick={()=>setSplash(false)} className="btn-primary mt-8 min-h-[52px] px-8 py-4 rounded-full font-extrabold text-lg shadow-lg" style={{animation:'bounceSoft 1.8s ease-in-out infinite, pulseGlow 2s infinite'}}>Mulai Buat Gratis <Sparkles className="inline ml-1" size={20}/></button>
      <p className="mt-4 text-xs text-white/50">3 Langkah • Tanpa Ribet • Download HD</p>
    </div>
  </div>}

    <div className="fixed inset-0 pointer-events-none z-0"><div className="orb w-[420px] h-[420px] bg-violet-700 left-[-120px] top-[12%]" /><div className="orb w-[360px] h-[360px] bg-pink-600 right-[-100px] top-[45%]" style={{animationDelay:'1.5s'}} /><div className="orb w-72 h-72 bg-sky-500 left-[38%] bottom-[-80px]" style={{animationDelay:'2.5s'}} /></div>
    <header data-safe-area-sticky-top style={{top:'var(--safe-area-inset-top)'}} className="sticky z-40 border-b border-white/10 bg-[#0a061a]/85 backdrop-blur-xl"><div className="max-w-[1440px] md:max-w-[960px] xl:max-w-[1440px] mx-auto px-5 md:px-6 xl:px-12 min-h-[64px] flex items-center justify-between gap-3 py-2"><a href="#atas" className="flex items-center gap-2 min-w-0"><span className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-pink-500 grid place-items-center font-black text-sm shadow-lg shrink-0">RAVN</span><span className="font-black leading-none truncate">LOGO3D <span className="text-pink-400">AI PRO</span></span></a><nav className="hidden md:flex gap-6 text-sm text-white/75"><a href="#editor" className="hover:text-white py-2">Buat Logo</a>{!simpleMode && <><a href="#warna-pro" className="hover:text-white py-2">Warna Pro</a><a href="#ai-saran" className="hover:text-white py-2">AI Saran</a></>}<a href="#galeri" className="hover:text-white py-2">Galeri</a></nav><div className="flex items-center gap-2 shrink-0"><button onClick={()=>go('editor')} className="btn-primary hidden sm:inline-flex min-h-[44px] items-center px-4 sm:px-5 py-2.5 rounded-full font-bold text-sm">Buat Sekarang</button><button onClick={()=>go('editor')} className="btn-primary sm:hidden min-h-[40px] px-3.5 rounded-full font-bold text-xs">Buat</button><button onClick={()=>setMenuOpen(v=>!v)} className="md:hidden min-w-[44px] min-h-[44px] grid place-items-center rounded-full bg-white/10 border border-white/10" aria-label="Buka menu" aria-expanded={menuOpen}>{menuOpen?<X size={20}/>:<Menu size={20}/>}</button></div></div>{menuOpen && <nav className="md:hidden border-t border-white/10 bg-[#0a061a] px-5 py-3 flex flex-col"><button onClick={()=>go('editor')} className="text-left min-h-[48px] py-2 font-bold border-b border-white/5">Buat Logo</button>{!simpleMode && <><button onClick={()=>go('warna-pro')} className="text-left min-h-[48px] py-2 font-bold border-b border-white/5">Warna Pro</button><button onClick={()=>go('ai-saran')} className="text-left min-h-[48px] py-2 font-bold border-b border-white/5">AI Saran</button></>}<button onClick={()=>go('galeri')} className="text-left min-h-[48px] py-2 font-bold">Galeri</button></nav>}</header>

    <main id="atas" className="relative z-10">
      <section className="relative overflow-hidden bg-gradient-to-b from-[#1a0b3d] via-[#2b105f] to-[#0a061a]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(168,85,247,.35),transparent_45%),radial-gradient(circle_at_85%_75%,rgba(236,72,153,.30),transparent_45%)]" />
        <div className="relative max-w-[1440px] md:max-w-[960px] xl:max-w-[1440px] mx-auto px-5 md:px-6 xl:px-12 pt-8 sm:pt-12 xl:pt-16 pb-10 xl:pb-16 text-center">
        <div className="min-w-0 max-w-3xl mx-auto"><div className="flex flex-wrap justify-center gap-2 mb-5"><span className="chip rounded-full px-3 py-1.5 text-xs font-bold">✦ Cuma 3 Langkah</span><span className="chip rounded-full px-3 py-1.5 text-xs font-bold">✦ Gratis</span><span className="chip rounded-full px-3 py-1.5 text-xs font-bold">✦ Tanpa Ribet</span></div>
        <h1 className="text-[32px] leading-[1.08] md:text-[44px] xl:text-[60px] xl:leading-[1.02] font-black break-words">RAVN — <span className="grad-text">Pembuat Logo 3D Gratis</span></h1>
        <p className="mt-5 text-base sm:text-lg text-white/70 max-w-xl mx-auto">Ketik nama brandmu, pilih gaya, pilih warna. Selesai! Tidak perlu bisa desain.</p>
        <div className="mt-7 flex flex-col sm:flex-row sm:flex-wrap gap-3 justify-center"><button onClick={()=>{ setSimpleMsg('Yuk, mulai dari Langkah 1 — ketik nama brand kamu!'); go('editor'); }} className="btn-primary w-full sm:w-auto min-h-[52px] px-6 py-3.5 rounded-full font-extrabold text-base">✨ Buat Logo Saya <Rocket className="inline ml-1" size={18}/></button><button onClick={handleConfused} className="chip w-full sm:w-auto min-h-[52px] px-6 py-3.5 rounded-full font-bold text-base">🤔 Saya Bingung? Klik Ini</button></div>
        <div className="mt-7 flex justify-center gap-5 sm:gap-8 text-sm text-white/60"><span className="min-w-0"><b className="text-white text-base sm:text-lg block break-all">12.400+</b>Logo dibuat</span><span className="min-w-0"><b className="text-white text-lg block">3</b>Langkah saja</span><span className="min-w-0"><b className="text-white text-lg block">Gratis</b>Selamanya</span></div></div></div>
      </section>

      {/* ============ EDITOR : TOGGLE + SIMPLE / LENGKAP ============ */}
      <section id="editor" className="max-w-[1440px] md:max-w-[960px] xl:max-w-[1440px] mx-auto px-5 md:px-6 xl:px-12 py-8 md:py-12">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-pink-300 font-bold text-sm tracking-widest">BUAT LOGO • 3 LANGKAH SAJA</p>
          <h2 className="text-3xl sm:text-4xl xl:text-[44px] font-black mt-1">Yuk, Buat Logomu Sekarang</h2>
          <p className="text-white/65 mt-2 text-base">Mode Simple cocok buat kamu yang baru pertama kali. Mau atur sampai detail? Pindah ke Mode Lengkap.</p>
        </div>

        {/* Toggle besar */}
        <div className="mt-6 mx-auto max-w-2xl grid grid-cols-2 gap-2 rounded-full bg-white/10 border border-white/15 p-1.5" role="group" aria-label="Pilih mode editor">
          <button onClick={()=>setSimpleMode(true)} aria-pressed={simpleMode} className={`min-h-[56px] rounded-full px-4 py-3 font-extrabold text-base flex items-center justify-center gap-2 ${simpleMode?'bg-white text-[#17102f] shadow-lg':'text-white/80'}`}>✨ Mode Simple</button>
          <button onClick={()=>setSimpleMode(false)} aria-pressed={!simpleMode} className={`min-h-[56px] rounded-full px-4 py-3 font-extrabold text-base flex items-center justify-center gap-2 ${!simpleMode?'bg-white text-[#17102f] shadow-lg':'text-white/80'}`}>⚙️ Mode Lengkap</button>
        </div>
        <p className="text-center text-sm text-white/60 mt-3">{simpleMode ? 'Kamu lagi di Mode Simple — cuma 3 langkah, tanpa yang bikin bingung.' : 'Kamu lagi di Mode Lengkap — semua pengaturan detail terbuka.'}</p>

        {simpleMode ? (
          <div className="mt-6">
            {/* Progress */}
            <div className="rounded-3xl border border-white/10 bg-[#17102f]/90 p-4 sm:p-5">
              <div className="flex flex-wrap items-center justify-between gap-2"><b className="text-base sm:text-lg">Langkah {currentStep} dari 3</b><span className="text-sm text-white/65">{completedCount===3 ? 'Semua selesai! Tinggal download 🎉' : `${completedCount} dari 3 sudah diisi`}</span></div>
              <div className="mt-3 h-4 rounded-full bg-white/10 overflow-hidden" role="progressbar" aria-valuenow={progressPct} aria-valuemin={0} aria-valuemax={100} aria-label={`Progres ${progressPct} persen`}><div className="h-full rounded-full bg-gradient-to-r from-violet-500 via-pink-500 to-sky-400 transition-all" style={{width:`${progressPct}%`}} /></div>
              <div className="mt-2 flex justify-between text-xs text-white/60"><span>1 • Nama</span><span>2 • Gaya</span><span>3 • Warna</span></div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.05fr] gap-5 mt-5 items-start">
              {/* Preview di atas (mobile) / kanan (desktop) */}
              <div id="preview-simple" className="order-1 lg:order-2 lg:sticky" style={{top:'calc(var(--safe-area-inset-top) + 84px)'}}>
                <div className="rounded-[26px] border border-white/10 bg-[#17102f]/90 p-3 sm:p-4">
                  <div className="flex items-center justify-between gap-2 mb-3"><div><h3 className="font-black text-lg">👀 Ini Logomu</h3><p className="text-sm text-white/60">Otomatis berubah saat kamu ketik & pilih.</p></div><span className="chip rounded-full px-3 py-1.5 text-xs font-bold shrink-0">LIVE</span></div>
                  <div ref={canvasRef} onPointerMove={onCanvasPointerMove} onPointerUp={endDrag} onPointerLeave={endDrag} className="relative w-full aspect-[4/3] sm:aspect-[16/11] overflow-hidden touch-none select-none rounded-2xl" style={{...bgStyle(design)}}>
                    {inspiration && inspirationMode==='background' && <div className="absolute inset-0" style={{background:inspiration.gradient, opacity:Math.max(0,Math.min(1,(100-inspirationTransparency)/100)), filter:`brightness(${inspirationBrightness}%)`}} />}
                    {inspiration && inspirationMode==='watermark' && <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[74%] h-[62%] rounded-full" style={{background:inspiration.gradient, opacity:0.45*(100-inspirationTransparency)/100, filter:`brightness(${inspirationBrightness}%) blur(2px)`}} />}
                    {layers.map(l=> l.visible && (
                      <div key={l.id} onPointerDown={(e)=>onLayerPointerDown(e,l,'move')} className="absolute" style={{left:`${l.x}%`, top:`${l.y}%`, transform:`translate(-50%,-50%) rotate(${l.rotation}deg)`, opacity:l.opacity, zIndex:10, cursor:'grab', touchAction:'none'}}>
                        <div className="relative p-2">{renderLayerContent(l,1)}</div>
                      </div>
                    ))}
                    <div className="absolute bottom-2 left-2 right-2 text-center"><span className="inline-block text-xs bg-black/55 rounded-full px-3 py-1.5">👆 Seret logo untuk pindah</span></div>
                  </div>
                  <p className="text-sm text-white/60 mt-3 text-center">Seret logo di atas kalau mau pindah posisi. Gampang, kan?</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
                    <button onClick={handleMakeLogo} className="btn-primary w-full min-h-[56px] rounded-2xl px-4 py-3 font-extrabold text-base">✨ Buat Logo Saya</button>
                    <button onClick={download} className="w-full min-h-[56px] rounded-2xl px-4 py-3 font-extrabold text-base bg-emerald-500 text-[#052e1d] flex items-center justify-center gap-2">⬇️ Download Logo</button>
                  </div>
                  <button onClick={saveDesign} disabled={busy} className="w-full mt-3 min-h-[52px] rounded-2xl bg-white/10 border border-white/10 font-bold text-base flex items-center justify-center gap-2 disabled:opacity-60"><Save size={18}/>{busy?'Menyimpan…':'Simpan Logo Saya'}</button>
                  {(simpleMsg||dlMsg||saveMsg) && <p className="mt-3 rounded-xl bg-emerald-500/15 border border-emerald-400/30 text-emerald-200 text-sm px-3 py-2.5 flex gap-2"><Check size={16} className="shrink-0 mt-0.5"/>{simpleMsg||dlMsg||saveMsg}</p>}
                  <button onClick={handleConfused} className="w-full mt-3 min-h-[52px] rounded-2xl bg-white/5 border border-white/15 font-bold text-base flex items-center justify-center gap-2"><HelpCircle size={18}/> Saya Bingung? Klik Ini</button>
                </div>
              </div>

              {/* 3 Langkah */}
              <div className="order-2 lg:order-1 space-y-5 min-w-0">
                <div className="rounded-[26px] border border-white/10 bg-[#17102f]/90 p-4 sm:p-5">
                  <div className="flex gap-3 items-start"><span className="w-11 h-11 shrink-0 rounded-full bg-gradient-to-br from-violet-600 to-pink-500 grid place-items-center font-black text-lg">1</span><div className="min-w-0"><h3 className="font-black text-xl">Ketik Nama Brand</h3><p className="text-sm text-white/60 mt-0.5">Nama usahamu, tokomu, atau channelmu.</p></div></div>
                  <label className="sr-only" htmlFor="simple-brand">Nama brand</label>
                  <input id="simple-brand" className="field mt-4 !py-4 text-lg font-bold min-h-[60px]" value={design.text} onChange={e=>handleSimpleBrand(e.target.value)} placeholder="Contoh: Kopi Kita" maxLength={18} />
                  <p className="text-sm text-white/50 mt-2">Maksimal 18 huruf. Contoh lain: Toko Rina, Salon Cantik.</p>
                </div>

                <div className="rounded-[26px] border border-white/10 bg-[#17102f]/90 p-4 sm:p-5">
                  <div className="flex gap-3 items-start"><span className="w-11 h-11 shrink-0 rounded-full bg-gradient-to-br from-violet-600 to-pink-500 grid place-items-center font-black text-lg">2</span><div className="min-w-0"><h3 className="font-black text-xl">Pilih Gaya</h3><p className="text-sm text-white/60 mt-0.5">Klik 1x — logomu langsung berubah.</p></div></div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4">
                    {SIMPLE_STYLES.map(s=>(
                      <button key={s.key} onClick={()=>applySimpleStyle(s)} aria-pressed={simpleStyleKey===s.key} className={`rounded-2xl border-2 p-4 text-left min-h-[104px] flex flex-col justify-between ${simpleStyleKey===s.key?'border-white bg-white text-[#17102f] shadow-lg':'border-white/15 bg-white/[.04]'}`}>
                        <span className="text-4xl" aria-hidden="true">{s.emoji}</span>
                        <span><b className="text-base block">{s.label}</b><span className={`text-sm block ${simpleStyleKey===s.key?'text-[#17102f]/70':'text-white/60'}`}>{s.desc}</span>{simpleStyleKey===s.key && <span className="text-sm font-bold mt-1 block">✓ Dipilih</span>}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="rounded-[26px] border border-white/10 bg-[#17102f]/90 p-4 sm:p-5">
                  <div className="flex gap-3 items-start"><span className="w-11 h-11 shrink-0 rounded-full bg-gradient-to-br from-violet-600 to-pink-500 grid place-items-center font-black text-lg">3</span><div className="min-w-0"><h3 className="font-black text-xl">Pilih Warna</h3><p className="text-sm text-white/60 mt-0.5">Klik bulatan warna yang kamu suka.</p></div></div>
                  <div className="grid grid-cols-4 gap-3 mt-4">
                    {SIMPLE_COLORS.map(p=>(
                      <button key={p.name} onClick={()=>applySimpleColor(p)} aria-label={`Warna ${p.name}`} title={p.name} className={`rounded-2xl border-2 p-2 min-h-[76px] flex flex-col items-center gap-1.5 ${design.color===p.c1 && simpleColorChosen?'border-white bg-white/10':'border-white/15 bg-white/[.03]'}`}>
                        <span className="w-12 h-12 rounded-full border-2 border-white/40 shrink-0" style={{background:`linear-gradient(135deg, ${p.c1}, ${p.c2})`}} />
                        <span className="text-xs font-bold text-center leading-tight">{p.name}</span>
                      </button>
                    ))}
                  </div>
                  <p className="text-sm text-white/50 mt-3">Mau warna yang lebih detail? Pindah ke <button onClick={()=>setSimpleMode(false)} className="font-bold text-white underline">Mode Lengkap</button> untuk 36+ palet & pengaturan warna lengkap.</p>
                </div>

                <div className="rounded-[26px] border border-white/10 bg-[#17102f]/90 p-4 sm:p-5">
                  <h3 className="font-black text-xl">Langkah 4 (Opsional): Pakai Inspirasi Warna</h3>
                  <p className="text-sm text-white/60 mt-1">Unggah foto dan file belum tersedia untuk saat ini. Sementara itu, coba 3 contoh inspirasi di bawah — warnanya langsung nempel ke logo.</p>
                  <div className="grid grid-cols-3 gap-2 sm:gap-3 mt-4">
                    {INSPIRATION_PRESETS.map(p=>(
                      <button key={p.key} onClick={()=>{ choosePreset(p); setSimplePhotoMsg(`Inspirasi ${p.name} dipakai — coba klik warna di bawahnya!`); }} aria-pressed={presetKey===p.key} className={`rounded-2xl overflow-hidden border-2 text-left min-w-0 ${presetKey===p.key ? 'border-white' : 'border-white/15'}`}>
                        <span className="block h-16 sm:h-20" style={{background:p.gradient}}><span className="block p-2 text-xl">{p.emoji}</span></span>
                        <span className="block p-2 sm:p-3 bg-[#17102f]"><b className="text-sm block truncate">{p.name}</b><span className="text-[11px] text-white/60 block truncate">Klik untuk memakai</span></span>
                      </button>
                    ))}
                  </div>
                  {inspiration && <div className="mt-3"><p className="text-sm font-bold mb-2">Warna dari {inspiration.name} — klik untuk pakai:</p><div className="flex flex-wrap gap-2">{inspiration.palette.map(c=>(<button key={c} onClick={()=>{ applySwatch(c); setSimpleColorChosen(true); }} className="min-w-[48px] min-h-[48px] rounded-full border-2 border-white/40" style={{background:c}} aria-label={`Pakai warna ${c}`} />))}</div></div>}
                  {simplePhotoMsg && <p className="mt-3 text-sm text-emerald-300">{simplePhotoMsg}</p>}
                  {inspirationMsg && <p className="mt-2 text-sm text-emerald-300">{inspirationMsg}</p>}
                  <button onClick={handleSimplePhoto} className="w-full mt-4 min-h-[52px] rounded-2xl bg-white/10 border border-white/15 font-bold text-base">Kenapa unggah foto belum tersedia?</button>
                  <a href="https://picsum.photos/600/400" target="_blank" rel="noopener" className="block w-full mt-3 min-h-[52px] rounded-2xl bg-white/10 border border-white/15 font-bold text-base text-center leading-[52px]">Coba Gambar Contoh</a>
                  <p className="mt-2 text-xs text-white/50">Tautan contoh di atas membuka gambar contoh di tab baru. Unggah foto belum tersedia di aplikasi ini.</p>
                </div>

                <div className="rounded-[26px] border border-white/10 bg-[#17102f]/90 p-4 sm:p-5">
                  <h3 className="font-black text-xl">✨ Mau Lihat Pilihan Lain?</h3>
                  <p className="text-sm text-white/60 mt-1">Sudah ikut gaya yang kamu pilih di Langkah 2. Tinggal klik!</p>
                  <button onClick={handleShowChoices} className="btn-primary w-full mt-4 min-h-[56px] rounded-2xl px-4 py-3 font-extrabold text-base">Lihat 6 Pilihan Lainnya</button>
                  {showSimpleChoices && <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-4">{suggestions.map((s,i)=>(<article key={s.name+i} className="rounded-2xl overflow-hidden border border-white/10 bg-[#0a061a] min-w-0"><div className="h-28"><Preview d={{...design,text:(aiBrand||'BRAND').toUpperCase().slice(0,14),font:s.font,shape:s.shape,style:s.style,color:s.c1,color2:s.c2,gradient:'Custom',depth:s.depth,rotY:s.rotY,anim:'Melayang'}} mini/></div><div className="p-3"><b className="text-sm block break-words leading-tight">{s.name}</b><span className="text-[11px] text-white/55 block break-words leading-snug">{s.font} • {s.shape} • {s.style}</span><button onClick={()=>applySuggestion(s)} className="w-full mt-2 min-h-[48px] rounded-xl bg-white text-[#17102f] font-bold text-sm px-2">Pakai Yang Ini</button></div></article>))}</div>}
                  {aiMsg && <p className="mt-3 text-sm text-emerald-300">{aiMsg}</p>}
                </div>

                <button onClick={handleConfused} className="w-full min-h-[56px] rounded-2xl bg-white/10 border border-white/15 font-bold text-base flex items-center justify-center gap-2"><HelpCircle size={20}/> Saya Bingung? Klik Ini — Kami Buatkan yang Bagus</button>
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-6">
            {/* ============ MODE LENGKAP : WARNA PRO ============ */}
            <section id="warna-pro" className="rounded-[26px] border border-white/10 bg-[#17102f]/90 p-4 sm:p-6 xl:p-8">
              <p className="text-pink-300 font-bold text-xs tracking-[.22em] flex items-center gap-2"><Palette size={16}/> FITUR 1 • AI PRO</p>
              <h2 className="text-2xl sm:text-3xl xl:text-4xl font-black mt-1">Warna Custom Pro</h2>
              <p className="text-white/65 text-sm mt-1 max-w-2xl">Dua warna campuran, slider Hue / Saturation / Brightness, 36+ palet, HEX manual, palet favorit tersimpan, background & bayangan 3D custom.</p>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mt-6">
                <div className="rounded-2xl border border-white/10 bg-white/[.03] p-4 min-w-0">
                  <h3 className="font-black">Warna Teks — Warna Campuran 2 Warna</h3>
                  {([1,2] as const).map(which=>{ const hsl=which===1?hsl1:hsl2; const hex=which===1?design.color:design.color2; const hexState=which===1?hex1:hex2; const setHexState=which===1?setHex1:setHex2; return (
                    <div key={which} className="mt-4 rounded-xl border border-white/10 p-3">
                      <div className="flex flex-wrap items-center gap-3">
                        <input type="color" value={hex} onChange={e=>{ if(which===1) set({color:e.target.value,gradient:'Custom'}); else set({color2:e.target.value,gradient:'Custom'}); }} aria-label={which===1?'Warna Teks Utama':'Warna Teks Kedua'} />
                        <div className="min-w-0"><b className="text-sm block">{which===1?'Warna Teks Utama':'Warna Teks Kedua (Warna Campuran)'}</b><span className="text-xs text-white/60">Hue {hsl.h}° • Sat {hsl.s}% • Bright {hsl.l}%</span></div>
                        <span className="ml-auto w-10 h-10 rounded-full border-2 border-white/40 shrink-0" style={{background:hex}} />
                      </div>
                      <div className="mt-3 space-y-1">
                        <label className="flex justify-between text-xs text-white/70"><span>Hue</span><b className="text-white">{hsl.h}°</b></label><input type="range" min={0} max={360} value={hsl.h} onChange={e=>setHsl(which,{h:Number(e.target.value)})} aria-label={`Hue warna ${which}`} />
                        <label className="flex justify-between text-xs text-white/70"><span>Saturation</span><b className="text-white">{hsl.s}%</b></label><input type="range" min={0} max={100} value={hsl.s} onChange={e=>setHsl(which,{s:Number(e.target.value)})} aria-label={`Saturation warna ${which}`} />
                        <label className="flex justify-between text-xs text-white/70"><span>Brightness</span><b className="text-white">{hsl.l}%</b></label><input type="range" min={0} max={100} value={hsl.l} onChange={e=>setHsl(which,{l:Number(e.target.value)})} aria-label={`Brightness warna ${which}`} />
                      </div>
                      <div className="flex gap-2 mt-2"><input className="field !py-2.5 text-sm font-mono2" value={hexState} onChange={e=>setHexState(e.target.value)} onBlur={()=>{ const v=hexState.trim(); if(/^#[0-9a-fA-F]{6}$/.test(v)){ if(which===1) set({color:v.toUpperCase(),gradient:'Custom'}); else set({color2:v.toUpperCase(),gradient:'Custom'}); } }} placeholder="#FF00AA" aria-label={`HEX warna ${which}`} /><button onClick={()=>copyTextToClipboard(hex,(ok)=>setColorMsg(ok?`HEX ${hex} tersalin!`:'Gagal menyalin.'))} className="chip rounded-xl min-w-[48px] min-h-[44px] px-3 flex items-center gap-1 text-xs font-bold"><Copy size={15}/> HEX</button></div>
                    </div> ); })}
                  <div className="flex flex-wrap gap-2 mt-4"><button onClick={randomColor} className="btn-primary rounded-full min-h-[48px] px-5 font-bold flex items-center gap-2"><Shuffle size={17}/> Acak Warna</button><button onClick={saveFav} className="chip rounded-full min-h-[48px] px-5 font-bold flex items-center gap-2"><HeartIcon size={17}/> Simpan Palet Favorit</button></div>
                  {colorMsg && <p className="text-xs text-emerald-300 mt-2">{colorMsg}</p>}{favMsg && <p className="text-xs text-emerald-300 mt-1">{favMsg}</p>}
                  {favPalettes.length>0 && <div className="mt-4"><p className="text-sm font-bold mb-2">Palet Favorit Tersimpan ({favPalettes.length}) — klik untuk pakai</p><div className="flex flex-wrap gap-2">{favPalettes.map((r:any)=>(<div key={r.id} className="flex items-center gap-1"><button onClick={()=>set({color:r.value.c1,color2:r.value.c2,shadowColor:r.value.shadow||design.shadowColor,glow:r.value.glow??design.glow,gradient:'Custom'})} className="h-11 px-3 rounded-full border border-white/20 text-xs font-bold flex items-center gap-2" style={{background:`linear-gradient(90deg, ${r.value.c1}, ${r.value.c2})`}}><span className="drop-shadow">{r.value.c1}</span><span className="drop-shadow">→</span><span className="drop-shadow">{r.value.c2}</span></button><button onClick={()=>deleteFav(r.id)} className="min-w-[36px] min-h-[36px] grid place-items-center rounded-full bg-white/10" aria-label="Hapus palet favorit"><Trash2 size={14}/></button></div>))}</div></div>}
                  {inspiration && <div className="mt-4"><p className="text-sm font-bold mb-2">Palet dari Gambar Inspirasi ({inspiration.name}) — klik untuk pakai</p><div className="flex flex-wrap gap-2">{inspiration.palette.map((c:string)=>(<button key={c} onClick={()=>applySwatch(c)} className="min-w-[44px] min-h-[44px] rounded-full border-2 border-white/40" style={{background:c}} aria-label={`Pakai warna ${c}`} />))}</div></div>}
                </div>
                <div className="min-w-0 space-y-4">
                  <div className="rounded-2xl border border-white/10 bg-white/[.03] p-4">
                    <h3 className="font-black">Warna Background Custom</h3>
                    <div className="flex items-center gap-3 mt-3"><input type="color" value={design.bg} onChange={e=>set({bg:e.target.value,bgMode:'solid',transparent:false})} aria-label="Warna background" /><span className="text-sm">Background: <b>{design.bg}</b></span><button onClick={()=>copyTextToClipboard(design.bg,(ok)=>setColorMsg(ok?'HEX background tersalin!':'Gagal menyalin.'))} className="chip rounded-lg px-3 py-2 text-xs font-bold flex items-center gap-1"><Copy size={13}/> Copy</button></div>
                    <p className="text-sm font-bold mt-4 mb-2">13 Background — klik untuk pakai</p>
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">{BG_OPTIONS.map(b=>(<button key={b.id} onClick={()=>set({bgMode:b.id,transparent:b.id==='transparent'})} className={`rounded-xl min-h-[48px] px-2 py-2 text-[11px] font-bold border-2 ${design.bgMode===b.id?'border-white':'border-white/15'}`} style={b.id==='black'?{background:'#000'}:b.id==='white'?{background:'#fff',color:'#111'}:b.id==='dark'?{background:'#070414'}:b.id==='navy'?{background:'#0f172a'}:b.id==='pinksoft'?{background:'#fdf2f8',color:'#111'}:b.id==='mintsoft'?{background:'#ecfdf5',color:'#111'}:b.id==='sunsetbg'?{background:'linear-gradient(135deg,#f97316,#ec4899)'}:b.id==='gradient'?{background:`linear-gradient(135deg,${design.bg},${design.color2})`}:b.id==='dots'?{backgroundColor:design.bg,backgroundImage:'radial-gradient(rgba(255,255,255,.4) 1.5px, transparent 1.5px)',backgroundSize:'14px 14px'}:b.id==='grid'?{backgroundColor:design.bg,backgroundImage:'linear-gradient(rgba(255,255,255,.25) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.25) 1px, transparent 1px)',backgroundSize:'12px 12px'}:b.id==='transparent'?{background:'repeating-conic-gradient(#3b345a 0% 25%, #241d44 0% 50%) 0 0 / 12px 12px'}:{background:design.bg}}>{b.label}</button>))}</div>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-white/[.03] p-4">
                    <h3 className="font-black">Warna Bayangan 3D / Depth + Glow</h3>
                    <div className="flex items-center gap-3 mt-3"><input type="color" value={design.shadowColor} onChange={e=>set({shadowColor:e.target.value})} aria-label="Warna bayangan 3D" /><span className="text-sm">Bayangan: <b>{design.shadowColor}</b></span></div>
                    <div className="mt-3"><div className="flex justify-between text-xs text-white/70"><span>Ketebalan Depth</span><b className="text-white">{design.depth}</b></div><input type="range" min={0} max={36} value={design.depth} onChange={e=>set({depth:Number(e.target.value)})} aria-label="Ketebalan Depth" /></div>
                    <div><div className="flex justify-between text-xs text-white/70"><span>Intensitas Glow</span><b className="text-white">{design.glow}</b></div><input type="range" min={0} max={80} value={design.glow} onChange={e=>set({glow:Number(e.target.value)})} aria-label="Intensitas Glow" /></div>
                    <div className="mt-3 rounded-xl p-4 text-center font-black text-xl" style={{background:design.bg, color:design.color, textShadow:`3px 3px 0 ${design.shadowColor}, 0 0 ${design.glow}px ${design.color2}`}}>PRATINJAU BAYANGAN</div>
                  </div>
                </div>
              </div>
              <div className="mt-5"><p className="font-black mb-2">36+ Preset Palet Warna Campuran — klik untuk pakai</p><div className="grid grid-cols-3 sm:grid-cols-6 lg:grid-cols-9 gap-2">{PALETTES.map(p=>(<button key={p.name} onClick={()=>applyPalette(p)} className="rounded-xl overflow-hidden border border-white/15 text-left min-w-0 hover:scale-[1.03] transition"><span className="block h-10" style={{background:`linear-gradient(135deg, ${p.c1}, ${p.c2}, ${p.c3||p.c2})`}} /><span className="block px-2 py-1.5 text-[11px] font-bold truncate bg-[#0a061a]">{p.name}</span></button>))}</div></div>
            </section>

            {/* AI SARAN LENGKAP */}
            <section id="ai-saran" className="mt-6 rounded-[26px] border border-white/10 bg-gradient-to-b from-violet-600/20 to-[#17102f]/90 p-4 sm:p-6 xl:p-8">
              <p className="text-pink-300 font-bold text-xs tracking-[.22em] flex items-center gap-2"><Sparkles size={16}/> FITUR 2 • AI PRO</p>
              <h2 className="text-2xl sm:text-3xl xl:text-4xl font-black mt-1">AI Saran Logo</h2>
              <p className="text-white/65 text-sm mt-1">AI membaca jenis usahamu & gaya yang kamu mau, lalu meracik font, warna, bentuk, dan gaya yang paling cocok.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-5">
                <label className="block"><span className="text-sm font-bold">Nama Brand</span><input className="field mt-1.5" value={aiBrand} onChange={e=>setAiBrand(e.target.value)} placeholder="Nama brandmu" /></label>
                <label className="block"><span className="text-sm font-bold">Jenis Usaha</span><select className="field mt-1.5" value={aiBiz} onChange={e=>setAiBiz(e.target.value)}>{['Gaming','Cafe','Toko Online','Beauty','Teknologi','Musik','Pendidikan','Lainnya'].map(x=><option key={x}>{x}</option>)}</select></label>
                <label className="block"><span className="text-sm font-bold">Gaya</span><select className="field mt-1.5" value={aiStyle} onChange={e=>setAiStyle(e.target.value)}>{['Modern','Elegan','Playful','Bold','Minimalis'].map(x=><option key={x}>{x}</option>)}</select></label>
                <div className="flex items-end gap-2"><button onClick={()=>{ setAiSeed(s=>s+1); genNamesTaglines(); setAiMsg(`6 saran AI untuk ${aiBiz} • gaya ${aiStyle} dibuat.`); }} className="btn-primary flex-1 min-h-[52px] rounded-xl font-extrabold px-4 flex items-center justify-center gap-2"><Wand2 size={18}/> Buat Saran AI</button><button onClick={()=>{ setAiSeed(s=>s+1); setAiMsg('6 saran lainnya dibuat — kombinasi baru.'); }} className="chip min-h-[52px] rounded-xl px-4 font-bold shrink-0">Saran Lainnya ↻</button></div>
              </div>
              {aiMsg && <p className="mt-3 text-sm text-emerald-300 flex gap-2"><Check size={16} className="shrink-0 mt-0.5"/>{aiMsg}</p>}
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 mt-4">{suggestions.map((s,i)=>(<article key={s.name+i} className="rounded-2xl overflow-hidden border border-white/10 bg-[#0a061a] min-w-0"><div className="h-28 sm:h-32"><Preview d={{...design,text:(aiBrand||'BRAND').toUpperCase().slice(0,14),font:s.font,shape:s.shape,style:s.style,color:s.c1,color2:s.c2,gradient:'Custom',depth:s.depth,rotY:s.rotY,anim:'Melayang'}} mini/></div><div className="p-3"><b className="text-sm block break-words leading-tight">{s.name}</b><span className="text-[11px] text-white/55 block break-words leading-snug">{s.font} • {s.shape} • {s.style}</span><span className="inline-flex gap-1 mt-2"><span className="w-5 h-5 rounded-full border border-white/30" style={{background:s.c1}}/><span className="w-5 h-5 rounded-full border border-white/30" style={{background:s.c2}}/></span><button onClick={()=>applySuggestion(s)} className="w-full mt-2 min-h-[44px] rounded-xl bg-white text-[#17102f] font-bold text-xs px-2">Pakai Desain Ini</button></div></article>))}</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-5">
                <div className="rounded-2xl border border-white/10 bg-white/[.03] p-4"><div className="flex justify-between items-center gap-2"><h3 className="font-black">Saran Nama AI</h3><button onClick={genNamesTaglines} className="chip rounded-full px-3 py-2 text-xs font-bold">Buat Lagi</button></div>{aiNames.length===0?<p className="text-sm text-white/60 mt-2">Klik “Buat Saran AI” untuk memunculkan 5 nama alternatif.</p>:<div className="flex flex-col gap-2 mt-3">{aiNames.map(n=>(<button key={n} onClick={()=>{ setAiBrand(n); set({text:n.toUpperCase()}); setAiMsg(`Nama “${n}” dipakai sebagai nama brand.`); }} className="text-left rounded-xl bg-white/5 border border-white/10 px-3 py-2.5 text-sm font-bold hover:bg-white/10 min-h-[44px]">{n} <span className="text-white/50 font-normal">— klik untuk pakai →</span></button>))}</div>}</div>
                <div className="rounded-2xl border border-white/10 bg-white/[.03] p-4"><h3 className="font-black">Saran Tagline AI</h3>{aiTaglines.length===0?<p className="text-sm text-white/60 mt-2">Klik “Buat Saran AI” untuk memunculkan 5 tagline.</p>:<div className="flex flex-col gap-2 mt-3">{aiTaglines.map(t=>(<button key={t} onClick={()=>{ setAiMsg(`Tagline dipilih: “${t}” — tempel di bio / kemasanmu.`); }} className="text-left rounded-xl bg-white/5 border border-white/10 px-3 py-2.5 text-sm hover:bg-white/10 min-h-[44px]">“{t}” <span className="text-white/50">— klik untuk pilih</span></button>))}</div>}</div>
              </div>
            </section>

            {/* EDITOR LENGKAP */}
            <div className="mt-6">
              <div className="reveal flex flex-wrap items-end justify-between gap-3 mb-4 sm:mb-6"><div className="min-w-0"><p className="text-pink-300 font-bold text-sm tracking-widest">EDITOR UTAMA • AI PRO</p><h2 className="text-3xl sm:text-4xl xl:text-[44px] font-black mt-1 break-words">Studio Logo 3D-mu</h2></div><button onClick={()=>setOpenSaved(v=>!v)} className="chip rounded-full min-h-[48px] px-4 py-2 text-sm font-bold flex items-center gap-2"><FolderOpen size={17}/> Tersimpan ({saved.length}) <ChevronDown size={16}/></button></div>
              {openSaved && <div className="mb-4 sm:mb-6 rounded-3xl border border-white/10 bg-white/5 p-4"><p className="font-bold mb-3">Desain yang kamu simpan</p>{saved.length===0?<p className="text-white/60 text-sm">Belum ada desain tersimpan. Buat desain lalu tekan “Simpan Desain”.</p>:<div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">{saved.map((r:any)=><div key={r.id} className="rounded-2xl overflow-hidden border border-white/10 bg-[#17102f] min-w-0"><div className="h-24"><Preview d={{...DEFAULTS,...r.value}} mini/></div><div className="p-2 flex gap-1"><button onClick={()=>{ setDesign({...DEFAULTS,...r.value}); if(r.value.layers) setLayers(r.value.layers); }} className="flex-1 min-h-[40px] bg-white/10 rounded-lg py-1.5 text-xs font-bold">Pakai</button><button onClick={()=>deleteSaved(r.id)} className="min-w-[40px] min-h-[40px] grid place-items-center p-1.5 rounded-lg bg-rose-500/20 text-rose-300" aria-label="Hapus desain"><Trash2 size={16}/></button></div></div>)}</div>}</div>}

              <div className="rounded-[26px] border border-white/10 bg-[#17102f]/90 p-4 sm:p-5 xl:p-6 mb-4 sm:mb-6 xl:mb-8 min-w-0">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-pink-300 font-bold text-xs tracking-[.22em] flex items-center gap-2"><Lightbulb size={16}/> INSPIRASI WARNA</p>
                    <h3 className="text-2xl sm:text-3xl font-black mt-1 break-words">Imajinasikan Logo dari Gambarmu</h3>
                    <p className="text-white/65 text-sm mt-1 max-w-2xl leading-relaxed">Pilih salah satu inspirasi contoh — palet, variasi, background, dan watermark-nya langsung diterapkan ke preview logo di bawah.</p>
                  </div>
                  {inspiration && <button onClick={clearInspiration} className="chip rounded-full min-h-[44px] px-4 py-2 text-sm font-bold shrink-0">Hapus Inspirasi</button>}
                </div>
                <div className="mt-4 rounded-2xl border border-white/10 bg-white/[.03] p-3 sm:p-4 flex items-start gap-3">
                  <span className="w-11 h-11 shrink-0 rounded-xl bg-white/10 grid place-items-center"><ImageOff size={20} className="text-white/70"/></span>
                  <p className="text-sm text-white/70 leading-relaxed min-w-0"><b className="text-white">Unggah foto dan file belum tersedia untuk saat ini.</b><br/>Aplikasi ini belum bisa menerima foto dari perangkatmu. Sementara itu, coba 3 inspirasi contoh di bawah — semuanya bekerja real-time di editor.</p>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.05fr] gap-4 sm:gap-5 mt-4 items-start min-w-0">
                  <div className="min-w-0">
                    <div className="rounded-2xl overflow-hidden border border-white/10 min-h-[180px] sm:min-h-[210px] relative flex items-end" style={{background: inspiration ? inspiration.gradient : 'linear-gradient(135deg,#2b1a5e,#3b0764)'}}>
                      <div className="absolute inset-0 bg-black/10" />
                      <div className="relative p-4 sm:p-5 min-w-0">
                        <p className="text-3xl" aria-hidden="true">{inspiration ? inspiration.emoji : '✨'}</p>
                        <p className="font-black text-xl sm:text-2xl mt-1 break-words">{inspiration ? `Inspirasi: ${inspiration.name}` : 'Pilih inspirasi contoh'}</p>
                        <p className="text-white/80 text-sm mt-1 leading-relaxed">{inspiration ? inspiration.desc : 'Klik salah satu contoh di bawah untuk melihat palet warnanya.'}</p>
                      </div>
                    </div>
                    <p className="text-sm font-bold mt-4 mb-2">3 inspirasi contoh — klik untuk mensimulasikan:</p>
                    <div className="grid grid-cols-3 gap-2 sm:gap-3">
                      {INSPIRATION_PRESETS.map(p=>(
                        <button key={p.key} onClick={()=>choosePreset(p)} aria-pressed={presetKey===p.key} className={`rounded-2xl overflow-hidden border-2 text-left min-w-0 ${presetKey===p.key ? 'border-white shadow-[0_10px_30px_rgba(236,72,153,.35)]' : 'border-white/15'}`}>
                          <span className="block h-16 sm:h-20" style={{background:p.gradient}}><span className="block p-2 text-xl">{p.emoji}</span></span>
                          <span className="block p-2 sm:p-3 bg-[#17102f]"><b className="text-sm block truncate">{p.name}</b><span className="text-[11px] text-white/60 block truncate">Klik untuk memakai</span></span>
                        </button>
                      ))}
                    </div>
                    {inspiration && <div className="mt-3 flex flex-wrap gap-2">{inspiration.palette.map(c=>(<button key={c} onClick={()=>applySwatch(c)} title={`Pakai warna ${c}`} className="min-w-[44px] min-h-[44px] rounded-full border-2 border-white/40 hover:border-white hover:scale-105 transition" style={{background:c}} aria-label={`Pakai warna ${c}`}><span className="sr-only">{c}</span></button>))}</div>}
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-[#0a061a]/60 p-4 sm:p-5 min-w-0">
                    <div className="flex items-center gap-2"><Sparkles size={18} className="text-pink-300 shrink-0"/><h4 className="font-black text-lg break-words">Hasil Imajinasi AI</h4></div>
                    {!inspiration ? (
                      <p className="text-white/60 text-sm mt-3 leading-relaxed">Belum ada inspirasi yang dipilih. Pilih <b className="text-white">Gunung</b>, <b className="text-white">Cafe</b>, atau <b className="text-white">Gaming</b> di kiri untuk memunculkan 5 palet warna dan 3 variasi logo otomatis.</p>
                    ) : (
                      <>
                        <p className="text-sm font-bold mt-4 mb-2 flex items-center gap-2"><Palette size={16}/> 5 palet warna hasil ekstrak — klik swatch untuk mengubah warna logo</p>
                        <div className="flex flex-wrap gap-2">
                          {inspiration.palette.map(c=>(<button key={c} onClick={()=>applySwatch(c)} className={`min-h-[44px] px-3 py-2 rounded-full text-xs font-bold border ${design.color===c && design.style==='Matte' ? 'border-white bg-white text-[#17102f]' : 'border-white/20 bg-white/5'}`}><span className="inline-block w-4 h-4 rounded-full align-middle mr-2 border border-white/40" style={{background:c}} />{c}</button>))}
                        </div>
                        <p className="text-sm font-bold mt-5 mb-2">3 variasi imajinasi — klik untuk terapkan ke editor</p>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          <button onClick={()=>applyVariation('asli')} aria-pressed={variation==='asli'} className={`rounded-2xl border p-3 text-left min-w-0 ${variation==='asli' ? 'border-white bg-white text-[#17102f]' : 'border-white/15 bg-white/[.04]'}`}><span className="block h-8 rounded-lg mb-2" style={{background:inspiration.palette[0]}} /><b className="text-sm block">Warna Asli</b><span className={`text-xs block leading-relaxed ${variation==='asli' ? 'text-[#17102f]/70' : 'text-white/60'}`}>Warna dominan untuk teks logo.</span></button>
                          <button onClick={()=>applyVariation('neon')} aria-pressed={variation==='neon'} className={`rounded-2xl border p-3 text-left min-w-0 ${variation==='neon' ? 'border-white bg-white text-[#17102f]' : 'border-white/15 bg-white/[.04]'}`}><span className="block h-8 rounded-lg mb-2" style={{background:inspiration.bright, boxShadow:`0 0 18px ${inspiration.bright}`}} /><b className="text-sm block">Neon dari Gambar</b><span className={`text-xs block leading-relaxed ${variation==='neon' ? 'text-[#17102f]/70' : 'text-white/60'}`}>Warna paling cerah + efek neon glow.</span></button>
                          <button onClick={()=>applyVariation('elegan')} aria-pressed={variation==='elegan'} className={`rounded-2xl border p-3 text-left min-w-0 ${variation==='elegan' ? 'border-white bg-white text-[#17102f]' : 'border-white/15 bg-white/[.04]'}`}><span className="block h-8 rounded-lg mb-2" style={{background:inspiration.dark}} /><b className="text-sm block">Elegan / Matte</b><span className={`text-xs block leading-relaxed ${variation==='elegan' ? 'text-[#17102f]/70' : 'text-white/60'}`}>Warna paling gelap + gaya matte.</span></button>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4">
                          <button onClick={useAsBackground} className={`rounded-2xl min-h-[52px] px-3 py-3 font-bold text-sm flex items-center justify-center gap-2 ${inspirationMode==='background' ? 'bg-white text-[#17102f]' : 'bg-violet-600'}`}><Layers size={17}/> Jadikan Background Logo {inspirationMode==='background' ? '✓' : ''}</button>
                          <button onClick={useAsWatermark} className={`rounded-2xl min-h-[52px] px-3 py-3 font-bold text-sm flex items-center justify-center gap-2 ${inspirationMode==='watermark' ? 'bg-white text-[#17102f]' : 'bg-white/10 border border-white/15'}`}><Eye size={17}/> Jadikan Bentuk / Watermark {inspirationMode==='watermark' ? '✓' : ''}</button>
                        </div>
                        <div className="mt-5 space-y-4">
                          <div><div className="flex justify-between gap-2 text-xs text-white/70"><span className="flex items-center gap-1 min-w-0"><Sun size={15}/> Kecerahan Inspirasi</span><b className="text-white shrink-0">{inspirationBrightness}%</b></div><input type="range" min={50} max={150} value={inspirationBrightness} onChange={e=>setInspirationBrightness(Number(e.target.value))} aria-label="Kecerahan Inspirasi" /></div>
                          <div><div className="flex justify-between gap-2 text-xs text-white/70"><span className="flex items-center gap-1 min-w-0"><Droplets size={15}/> Transparansi Gambar</span><b className="text-white shrink-0">{inspirationTransparency}% • Opasitas {100-inspirationTransparency}%</b></div><input type="range" min={0} max={100} value={inspirationTransparency} onChange={e=>setInspirationTransparency(Number(e.target.value))} aria-label="Transparansi Gambar" /></div>
                        </div>
                        <p className="text-xs text-white/50 mt-3 leading-relaxed">Mode aktif: <b className="text-white">{inspirationMode==='background' ? 'Background Logo' : inspirationMode==='watermark' ? 'Bentuk / Watermark' : 'Belum ada'}</b> — Download PNG ikut menyertakan background / watermark yang dipilih.</p>
                      </>
                    )}
                    {inspirationMsg && <p className="mt-4 rounded-xl bg-emerald-500/15 border border-emerald-400/30 text-emerald-200 text-sm px-3 py-2.5 flex gap-2"><Check size={16} className="shrink-0 mt-0.5"/>{inspirationMsg}</p>}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-[300px_minmax(0,1fr)] lg:grid-cols-[420px_minmax(0,1fr)] xl:grid-cols-[520px_minmax(0,1fr)] gap-4 sm:gap-5 xl:gap-8 items-start">
                <div className="order-2 md:order-1 rounded-[26px] border border-white/10 bg-[#17102f]/90 p-4 sm:p-5 xl:p-6 space-y-4 min-w-0">
                  <Accordion title="Teks & Font" icon={<Type size={17}/>} open={!!openSections.teks} onToggle={()=>toggleSection('teks')}>
                    <label className="text-sm font-bold">Teks Logo</label><input className="field mt-2 min-h-[52px]" value={design.text} onChange={e=>set({text:e.target.value.slice(0,18)})} placeholder="BRANDKU" maxLength={18}/><p className="text-xs text-white/50 mt-1">Maksimal 18 karakter.</p>
                    <p className="text-sm font-bold mt-4 mb-2">Font</p><div className="grid grid-cols-2 gap-2">{Object.keys(FONTS).map(f=><button key={f} onClick={()=>set({font:f})} className={`chip rounded-xl min-h-[48px] px-3 py-2.5 text-left text-sm font-bold break-words ${design.font===f?'active':''}`} style={{fontFamily:FONTS[f]}}>{f}</button>)}</div>
                  </Accordion>
                  <Accordion title="Warna & Warna Campuran" icon={<Palette size={17}/>} open={!!openSections.warna} onToggle={()=>toggleSection('warna')}>
                    <div className="flex gap-2 flex-wrap">{Object.keys(GRADIENTS).map(g=><button key={g} onClick={()=>set({gradient:g})} className={`min-h-[48px] rounded-xl border-2 px-2 text-[11px] font-bold ${design.gradient===g?'border-white':'border-white/20'}`} style={{background:GRADIENTS[g]}}>{g}</button>)}</div>
                    <div className="flex flex-wrap items-center gap-3 mt-4"><div className="flex items-center gap-2"><input type="color" value={design.color} onChange={e=>set({color:e.target.value})} aria-label="Warna teks"/><span className="text-sm">Teks <b className="break-all">{design.color}</b></span></div><div className="flex items-center gap-2"><input type="color" value={design.bg} onChange={e=>set({bg:e.target.value})} aria-label="Warna latar"/><span className="text-sm">Latar</span></div></div>
                    <label className="flex items-start gap-2 mt-4 text-sm leading-snug"><input type="checkbox" checked={design.transparent} onChange={e=>set({transparent:e.target.checked})} className="w-5 h-5 mt-0.5 shrink-0 accent-pink-500"/> Latar transparan (pola papan catur)</label>
                    <a href="#warna-pro" className="mt-3 block text-center chip rounded-xl min-h-[48px] py-3 text-sm font-bold">Buka Warna Custom Pro → 36+ Palet</a>
                  </Accordion>
                  <Accordion title="Atur Dimensi" icon={<SlidersHorizontal size={17}/>} open={!!openSections.dimensi} onToggle={()=>toggleSection('dimensi')}>
                    {([['Ukuran','size',36,110],['Ketebalan 3D / Depth','depth',0,36],['Rotasi X','rotX',-35,35],['Rotasi Y','rotY',-45,45],['Kemiringan','tilt',-20,20]] as const).map(([label,key,min,max])=><div key={key} className="mt-4 first:mt-1"><div className="flex justify-between gap-2 text-xs text-white/70"><span className="min-w-0">{label}</span><b className="text-white shrink-0">{(design as any)[key]}°</b></div><input type="range" min={min} max={max} value={(design as any)[key]} onChange={e=>set({[key]:Number(e.target.value)} as any)} aria-label={label}/></div>)}
                  </Accordion>
                  <Accordion title="Bentuk Ikon" icon={<Shapes size={17}/>} open={!!openSections.bentuk} onToggle={()=>toggleSection('bentuk')}>
                    <div className="grid grid-cols-3 gap-2">{SHAPES.map(s=><button key={s} onClick={()=>set({shape:s})} className={`chip rounded-xl min-h-[56px] py-2.5 text-xs font-bold flex flex-col items-center justify-center gap-1 ${design.shape===s?'active':''}`}>{shapeIcon(s,22)}{s}</button>)}</div>
                  </Accordion>
                  <Accordion title="Gaya & Animasi" icon={<Zap size={17}/>} open={!!openSections.gaya} onToggle={()=>toggleSection('gaya')}>
                    <p className="text-sm font-bold">Gaya Permukaan</p><div className="flex flex-wrap gap-2 mt-2">{STYLES.map(s=><button key={s} onClick={()=>set({style:s})} className={`chip rounded-full min-h-[44px] px-3 py-2 text-xs font-bold ${design.style===s?'active':''}`}>{s}</button>)}</div>
                    <p className="text-sm font-bold mt-4 mb-2 flex gap-2 items-center"><Zap size={17}/> Animasi</p><div className="flex flex-wrap gap-2">{ANIMS.map(s=><button key={s} onClick={()=>set({anim:s})} className={`chip rounded-full min-h-[44px] px-3 py-2 text-xs font-bold ${design.anim===s?'active':''}`}>{s}</button>)}</div>
                  </Accordion>
                  <div className="grid grid-cols-2 gap-2 pt-1"><button onClick={randomize} className="rounded-xl bg-violet-600 min-h-[52px] py-3 font-bold flex items-center justify-center gap-2 px-2"><Shuffle size={18}/> Acak Desain</button><button onClick={reset} className="rounded-xl bg-white/10 min-h-[52px] py-3 font-bold flex items-center justify-center gap-2 px-2"><RotateCcw size={18}/> Reset</button></div>
                </div>

                <div className="order-1 md:order-2 min-w-0 lg:sticky" style={{top:'calc(var(--safe-area-inset-top) + 84px)'}}>
                  <div className="rounded-[26px] border border-white/10 bg-[#17102f]/90 p-3 sm:p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-3"><div><h3 className="font-black flex items-center gap-2"><Move size={18} className="text-pink-300"/> Canvas Logo — Bisa Ditarik</h3><p className="text-xs text-white/60">Tarik lapisan dengan mouse / sentuhan. Pakai handle pojok untuk ukuran & putar.</p></div><div className="flex gap-1"><button onClick={undo} disabled={!past.length} className="chip rounded-lg min-w-[44px] min-h-[44px] grid place-items-center disabled:opacity-40" aria-label="Undo"><Undo2 size={18}/></button><button onClick={redo} disabled={!future.length} className="chip rounded-lg min-w-[44px] min-h-[44px] grid place-items-center disabled:opacity-40" aria-label="Redo"><Redo2 size={18}/></button></div></div>
                    <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_230px] gap-3 items-start">
                      <div className="min-w-0">
                        <div className="overflow-auto rounded-2xl border border-white/15" style={{maxHeight:560}}>
                          <div style={{transform:`scale(${zoom/100})`, transformOrigin:'top left', width:`${10000/zoom}%`}} className="min-w-0">
                            <div ref={canvasRef} onPointerMove={onCanvasPointerMove} onPointerUp={endDrag} onPointerLeave={endDrag} className="relative w-full aspect-[4/3] sm:aspect-[16/10] overflow-hidden touch-none select-none" style={{...bgStyle(design), borderRadius:16}}>
                              {inspiration && inspirationMode==='background' && <div className="absolute inset-0" style={{background:inspiration.gradient, opacity:Math.max(0,Math.min(1,(100-inspirationTransparency)/100)), filter:`brightness(${inspirationBrightness}%)`}} />}
                              {inspiration && inspirationMode==='watermark' && <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[74%] h-[62%] rounded-full" style={{background:inspiration.gradient, opacity:0.45*(100-inspirationTransparency)/100, filter:`brightness(${inspirationBrightness}%) blur(2px)`}} />}
                              {layers.map(l=> l.visible && (
                                <div key={l.id} onPointerDown={(e)=>onLayerPointerDown(e,l,'move')} className="absolute" style={{left:`${l.x}%`, top:`${l.y}%`, transform:`translate(-50%,-50%) rotate(${l.rotation}deg)`, opacity:l.opacity, zIndex:10, cursor:'grab', touchAction:'none'}}>
                                  <div className={`relative p-2 ${selectedId===l.id?'outline outline-2 outline-pink-400 rounded-lg bg-white/10':''}`}>{renderLayerContent(l,1)}
                                    {selectedId===l.id && <>
                                      <button onPointerDown={(e)=>onLayerPointerDown(e,l,'resize')} className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-white text-[#17102f] grid place-items-center shadow font-black text-xs touch-none" aria-label="Ubah ukuran">↘</button>
                                      <button onPointerDown={(e)=>onLayerPointerDown(e,l,'rotate')} className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-pink-500 text-white grid place-items-center shadow touch-none" aria-label="Putar"><RotateCw size={14}/></button>
                                      <button onClick={(e)=>{ e.stopPropagation(); deleteLayer(l.id); }} className="absolute -top-2 -left-2 w-7 h-7 rounded-full bg-rose-500 text-white grid place-items-center shadow" aria-label="Hapus lapisan"><Trash size={13}/></button>
                                    </>}
                                  </div>
                                </div>
                              ))}
                              <div className="absolute bottom-2 left-2 text-[10px] bg-black/50 rounded-full px-2 py-1 pointer-events-none">Tarik lapisan • Handle ↘ ukuran • ⟳ putar • ✕ hapus</div>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-2 mt-3">
                          <button onClick={addText} className="chip rounded-full min-h-[44px] px-3 py-2 text-xs font-bold flex items-center gap-1"><Plus size={15}/> Tambah Teks</button>
                          <button onClick={()=>addShape('Bintang')} className="chip rounded-full min-h-[44px] px-3 py-2 text-xs font-bold flex items-center gap-1"><Plus size={15}/> Tambah Bentuk</button>
                          <span className="flex flex-wrap gap-1">{STICKERS.slice(0,6).map(s=>(<button key={s} onClick={()=>addSticker(s)} className="min-w-[40px] min-h-[40px] rounded-full bg-white/10 text-lg hover:bg-white/20" aria-label={`Tambah stiker ${s}`}>{s}</button>))}</span>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <span className="text-xs font-bold py-2">Bentuk:</span>{SHAPE_ADD.map(s=>(<button key={s} onClick={()=>addShape(s)} className="chip rounded-full min-h-[40px] px-3 text-xs font-bold">{s}</button>))}
                        </div>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <span className="text-xs font-bold py-2">Stiker:</span>{STICKERS.map(s=>(<button key={s} onClick={()=>addSticker(s)} className="min-w-[40px] min-h-[40px] rounded-full bg-white/10 text-lg hover:bg-white/20" aria-label={`Tambah stiker ${s}`}>{s}</button>))}
                        </div>
                        <div className="flex flex-wrap items-center gap-2 mt-3">
                          <span className="text-xs font-bold">Snap / Align:</span>
                          <button onClick={()=>align('left')} className="chip rounded-full min-h-[44px] px-3 text-xs font-bold flex items-center gap-1"><AlignLeft size={15}/> Rata Kiri</button>
                          <button onClick={()=>align('center')} className="chip rounded-full min-h-[44px] px-3 text-xs font-bold flex items-center gap-1"><AlignCenter size={15}/> Rata Tengah</button>
                          <button onClick={()=>align('right')} className="chip rounded-full min-h-[44px] px-3 text-xs font-bold flex items-center gap-1"><AlignRight size={15}/> Rata Kanan</button>
                          <span className="ml-auto flex items-center gap-2 text-xs font-bold"><ZoomIn size={15}/> Zoom {zoom}%</span>
                        </div>
                        <input type="range" min={50} max={150} value={zoom} onChange={e=>setZoom(Number(e.target.value))} aria-label="Zoom preview" />
                        {canvasMsg && <p className="text-xs text-emerald-300 mt-1">{canvasMsg}</p>}
                      </div>
                      <aside className="rounded-2xl border border-white/10 bg-[#0a061a]/70 p-3 min-w-0">
                        <h4 className="font-black flex items-center gap-2"><Layers size={16}/> Panel Lapisan ({layers.length})</h4>
                        <p className="text-[11px] text-white/55 mt-1">Klik lapisan untuk pilih. Atas = paling depan.</p>
                        <div className="flex flex-col gap-2 mt-3 max-h-[320px] overflow-auto pr-1">
                          {layers.map((l,idx)=>(
                            <div key={l.id} onClick={()=>setSelectedId(l.id)} className={`rounded-xl border p-2 cursor-pointer min-w-0 ${selectedId===l.id?'border-pink-400 bg-pink-500/15':'border-white/10 bg-white/[.03]'}`}>
                              <div className="flex items-center gap-2 min-w-0"><span className="text-lg shrink-0">{l.kind==='text'?'T':l.kind==='shape'?'⬢':'✦'}</span><div className="min-w-0 flex-1"><b className="text-xs block truncate">{l.label}</b><span className="text-[11px] text-white/55 block truncate">{l.content} • X {Math.round(l.x)}% Y {Math.round(l.y)}%</span></div><button onClick={(e)=>{e.stopPropagation(); updateLayer(l.id,{visible:!l.visible});}} className="shrink-0 min-w-[36px] min-h-[36px] grid place-items-center rounded-lg bg-white/10" aria-label="Sembunyikan lapisan">{l.visible?<Eye size={15}/>:<EyeOff size={15}/>}</button></div>
                              <div className="flex gap-1 mt-2">
                                <button onClick={(e)=>{e.stopPropagation(); moveLayer(l.id,-1);}} className="flex-1 min-h-[36px] rounded-lg bg-white/10 text-[11px] font-bold flex items-center justify-center gap-1"><ChevronUp size={13}/> Naik</button>
                                <button onClick={(e)=>{e.stopPropagation(); moveLayer(l.id,1);}} className="flex-1 min-h-[36px] rounded-lg bg-white/10 text-[11px] font-bold flex items-center justify-center gap-1"><ChevronDownIcon size={13}/> Turun</button>
                                <button onClick={(e)=>{e.stopPropagation(); duplicateLayer(l);}} className="flex-1 min-h-[36px] rounded-lg bg-white/10 text-[11px] font-bold flex items-center justify-center gap-1"><CopyIcon size={13}/> Duplikat</button>
                                <button onClick={(e)=>{e.stopPropagation(); deleteLayer(l.id);}} className="flex-1 min-h-[36px] rounded-lg bg-rose-500/20 text-[11px] font-bold flex items-center justify-center gap-1"><Trash size={13}/> Hapus</button>
                              </div>
                            </div>
                          ))}
                        </div>
                        {selected ? <div className="mt-3 border-t border-white/10 pt-3">
                          <p className="font-bold text-sm">Kontrol: {selected.label}</p>
                          <div className="mt-2"><label className="flex justify-between text-xs text-white/70"><span>Posisi X</span><b className="text-white">{Math.round(selected.x)}%</b></label><input type="range" min={0} max={100} value={selected.x} onChange={e=>updateLayer(selected.id,{x:Number(e.target.value)})} aria-label="Posisi X lapisan" /></div>
                          <div><label className="flex justify-between text-xs text-white/70"><span>Posisi Y</span><b className="text-white">{Math.round(selected.y)}%</b></label><input type="range" min={0} max={100} value={selected.y} onChange={e=>updateLayer(selected.id,{y:Number(e.target.value)})} aria-label="Posisi Y lapisan" /></div>
                          <div><label className="flex justify-between text-xs text-white/70"><span>Ukuran</span><b className="text-white">{Math.round(selected.size)}</b></label><input type="range" min={20} max={180} value={selected.size} onChange={e=>updateLayer(selected.id,{size:Number(e.target.value)})} aria-label="Ukuran lapisan" /></div>
                          <div><label className="flex justify-between text-xs text-white/70"><span>Rotasi</span><b className="text-white">{selected.rotation}°</b></label><input type="range" min={-180} max={180} value={selected.rotation} onChange={e=>updateLayer(selected.id,{rotation:Number(e.target.value)})} aria-label="Rotasi lapisan" /></div>
                          <div><label className="flex justify-between text-xs text-white/70"><span>Transparan</span><b className="text-white">{Math.round(selected.opacity*100)}%</b></label><input type="range" min={10} max={100} value={selected.opacity*100} onChange={e=>updateLayer(selected.id,{opacity:Number(e.target.value)/100})} aria-label="Transparan lapisan" /></div>
                          {selected.kind==='text' && <><label className="text-xs font-bold mt-2 block">Isi Teks Lapisan</label><input className="field mt-1 !py-2 text-sm" value={selected.content} onChange={e=>updateLayer(selected.id,{content:e.target.value.slice(0,20)})} /></>}
                          <label className="text-xs font-bold mt-2 block">Warna Lapisan</label><div className="flex items-center gap-2 mt-1"><input type="color" value={selected.color} onChange={e=>updateLayer(selected.id,{color:e.target.value})} aria-label="Warna lapisan" /><span className="text-xs">{selected.color}</span></div>
                        </div> : <p className="text-xs text-white/55 mt-3">Klik salah satu lapisan untuk mengatur Posisi X/Y, Ukuran, Rotasi & Transparan.</p>}
                      </aside>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 mt-3"><button onClick={download} className="btn-primary rounded-2xl min-h-[52px] py-3.5 px-2 font-extrabold flex items-center justify-center gap-2 text-sm sm:text-base"><Download size={19}/> Download PNG</button><button onClick={copyText} className="rounded-2xl bg-white/10 border border-white/10 min-h-[52px] py-3.5 px-2 font-bold flex items-center justify-center gap-2 text-sm sm:text-base"><Copy size={18}/> Salin</button><button onClick={saveDesign} disabled={busy} className="rounded-2xl bg-emerald-500 text-[#052e1d] min-h-[52px] py-3.5 px-2 font-extrabold flex items-center justify-center gap-2 disabled:opacity-60 text-sm sm:text-base"><Save size={18}/>{busy?'Menyimpan…':'Simpan Desain'}</button><button onClick={()=>set({anim:design.anim==='Putar'?'Melayang':'Putar'})} className="rounded-2xl bg-sky-500 min-h-[52px] py-3.5 px-2 font-bold flex items-center justify-center gap-2 text-sm sm:text-base"><Play size={18}/> Putar / Jeda</button></div>
                  {(dlMsg||copyMsg||saveMsg)&&<div className="mt-3 flex flex-wrap gap-2 text-sm"><span className="bg-emerald-500/15 text-emerald-200 border border-emerald-400/30 rounded-full px-3 py-1.5 flex gap-2"><Check size={16} className="shrink-0 mt-0.5"/>{dlMsg||copyMsg||saveMsg}</span></div>}
                  <p className="text-xs text-white/50 mt-3 leading-relaxed">PNG diekspor 1200 × 760 piksel dengan posisi lapisan yang sudah ditarik. Desain + lapisan tersimpan tersinkron lewat layanan data aplikasi dan bisa dibuka lagi dari panel “Tersimpan”. Unggah foto dan file belum tersedia — lapisan memakai inspirasi & stiker bawaan.</p>
                </div>
              </div>
            </div>

            <section id="template" className="mt-12"><div className="reveal"><p className="text-pink-300 font-bold text-sm tracking-widest">GALERI TEMPLATE</p><h2 className="text-3xl sm:text-4xl xl:text-[44px] font-black mt-1 break-words">Mulai dari template favoritmu</h2><p className="text-white/65 mt-2">Klik template — editor langsung terisi.</p></div><div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 xl:gap-5 mt-6">{TEMPLATES.map(t=><button key={t.name} onClick={()=>applyTemplate(t)} className="tilt-card text-left rounded-3xl overflow-hidden border border-white/10 bg-[#17102f] min-w-0"><div className="h-32 sm:h-40 xl:h-44"><Preview d={{...DEFAULTS,...t.d}} mini/></div><div className="p-3 sm:p-4"><span className="text-[10px] tracking-widest font-bold text-pink-300">{t.cat.toUpperCase()}</span><div className="font-extrabold mt-1 flex justify-between items-center gap-2 min-w-0"><span className="truncate">{t.name}</span><MousePointerClick size={17} className="text-white/50 shrink-0"/></div><span className="text-xs text-white/55">Klik untuk memakai →</span></div></button>)}</div></section>
          </div>
        )}
      </section>

      <section id="fitur" className="max-w-[1440px] md:max-w-[960px] xl:max-w-[1440px] mx-auto px-5 md:px-6 xl:px-12 py-12 md:py-16 xl:py-24"><h2 className="reveal text-3xl sm:text-4xl xl:text-[44px] font-black text-center break-words">Kenapa jutaan kreator memilih kami?</h2><div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 xl:gap-5 mt-7">{[{i:'🎁',t:'Gratis Selamanya',d:'Semua fitur inti bisa dipakai tanpa biaya tersembunyi.'},{i:'✦',t:'Tanpa Watermark',d:'Logo bersih dan siap dipakai untuk brand profesional.'},{i:'🖼️',t:'Download HD',d:'Ekspor PNG tajam untuk media sosial dan kemasan.'},{i:'♾️',t:'Ribuan Kombinasi',d:'Font, warna, bentuk, gaya, dan animasi bisa dipadukan.'}].map((f,i)=><article key={f.t} className="reveal tilt-card rounded-3xl border border-white/10 bg-white/[.05] p-5 min-w-0" style={{transitionDelay:`${i*40}ms`}}><div className="text-4xl mb-3">{f.i}</div><h3 className="font-extrabold text-lg break-words">{f.t}</h3><p className="text-white/65 text-sm mt-2 leading-relaxed">{f.d}</p></article>)}</div></section>

      <section className="max-w-[1440px] md:max-w-[960px] xl:max-w-[1440px] mx-auto px-5 md:px-6 xl:px-12 py-12 md:py-16 xl:py-24"><h2 className="reveal text-3xl sm:text-4xl xl:text-[44px] font-black text-center break-words">Cara Pakai — semudah 1, 2, 3</h2><div className="grid md:grid-cols-3 gap-4 xl:gap-5 mt-7">{[{n:'1',t:'Ketik Nama Brand',d:'Masukkan nama usaha, channel, atau komunitasmu.',icon:<PenLine/>},{n:'2',t:'Pilih Gaya',d:'Klik 1 gaya yang paling mirip usahamu.',icon:<Wand2/>},{n:'3',t:'Pilih Warna & Unduh',d:'Klik warna yang kamu suka, lalu download.',icon:<Download/>}].map(s=><div key={s.n} className="reveal relative rounded-3xl border border-white/10 bg-gradient-to-b from-violet-600/25 to-transparent p-6 text-center min-w-0"><div className="w-14 h-14 mx-auto rounded-full bg-gradient-to-br from-violet-600 to-pink-500 grid place-items-center font-black text-2xl shadow-lg">{s.n}</div><div className="flex justify-center mt-4 text-pink-300">{s.icon}</div><h3 className="font-extrabold text-xl mt-2 break-words">{s.t}</h3><p className="text-white/65 text-sm mt-2">{s.d}</p></div>)}</div></section>

      <section id="galeri" className="max-w-[1440px] md:max-w-[960px] xl:max-w-[1440px] mx-auto px-5 md:px-6 xl:px-12 py-12 md:py-16 xl:py-24 pb-16 xl:pb-24"><div className="reveal flex flex-wrap items-end justify-between gap-3"><div className="min-w-0"><p className="text-pink-300 font-bold text-sm tracking-widest">GALERI INSPIRASI</p><h2 className="text-3xl sm:text-4xl xl:text-[44px] font-black mt-1 break-words">Butuh inspirasi?</h2></div><span className="hidden sm:block text-sm text-white/55">Arahkan kursor untuk efek tilt 3D</span></div><div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 xl:gap-5 mt-6">{INSPO.map(x=><div key={x.t} className="tilt-card rounded-3xl overflow-hidden border border-white/10 min-w-0"><div className="h-40 sm:h-52 xl:h-56"><Preview d={{...DEFAULTS,text:x.t,gradient:x.g,style:x.s,shape:x.sh,anim:'Melayang'}} mini/></div><div className="p-3 bg-[#17102f] flex flex-col gap-1 text-sm min-w-0"><b className="truncate">{x.t}</b><span className="text-white/55 break-words leading-tight">{x.s}</span></div></div>)}</div></section>
    </main>
    <footer className="relative z-10 border-t border-white/10 bg-[#08051a]/90"><div className="max-w-[1440px] md:max-w-[960px] xl:max-w-[1440px] mx-auto px-5 md:px-6 xl:px-12 py-10 grid md:grid-cols-3 gap-6"><div className="min-w-0"><div className="flex gap-2 items-center font-black text-lg"><span className="w-9 h-9 rounded-lg bg-gradient-to-br from-violet-600 to-pink-500 grid place-items-center shrink-0">3D</span><span className="truncate">LOGO3D AI PRO</span></div><p className="text-white/60 text-sm mt-3 max-w-xs">Pembuat logo 3D online gratis. Buat brandmu terlihat premium dalam satu menit.</p></div><div className="text-sm text-white/65"><b className="text-white">Jelajahi</b><div className="mt-3 space-y-2"><a href="#editor" className="block hover:text-white min-h-[40px] py-1">Buat Logo</a>{!simpleMode && <><a href="#warna-pro" className="block hover:text-white min-h-[40px] py-1">Warna Pro</a><a href="#ai-saran" className="block hover:text-white min-h-[40px] py-1">AI Saran</a></>}<a href="#galeri" className="block hover:text-white min-h-[40px] py-1">Galeri Inspirasi</a></div></div><div className="text-sm text-white/65 min-w-0"><b className="text-white">Janji Kami</b><p className="mt-3">Gratis selamanya • Tanpa watermark • Tanpa login • Download HD</p><p className="mt-4 text-xs">© 2026 Logo3D Gratis. Dibuat untuk kreator Indonesia.</p></div></div></footer>
  </div>
}
